﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MainDisplay = New System.Windows.Forms.PictureBox()
        Me.gPress = New System.Windows.Forms.Timer(Me.components)
        Me.pControl = New System.Windows.Forms.Panel()
        Me.gbPaintFill = New System.Windows.Forms.GroupBox()
        Me.cbFillplane = New System.Windows.Forms.CheckBox()
        Me.btnColorSwitchFB = New System.Windows.Forms.Button()
        Me.btnColorSwitchFG = New System.Windows.Forms.Button()
        Me.btnColorSwitchFR = New System.Windows.Forms.Button()
        Me.btnColorSwitchFA = New System.Windows.Forms.Button()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.tbPaintVFB = New System.Windows.Forms.TextBox()
        Me.btnPaintFBdown = New System.Windows.Forms.Button()
        Me.btnPaintFBup = New System.Windows.Forms.Button()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.tbPaintVFG = New System.Windows.Forms.TextBox()
        Me.tbPaintVFR = New System.Windows.Forms.TextBox()
        Me.tbPaintVFA = New System.Windows.Forms.TextBox()
        Me.btnPaintFAup = New System.Windows.Forms.Button()
        Me.btnPaintFAdown = New System.Windows.Forms.Button()
        Me.btnPaintFRdown = New System.Windows.Forms.Button()
        Me.btnPaintFRup = New System.Windows.Forms.Button()
        Me.btnPaintFGdown = New System.Windows.Forms.Button()
        Me.btnPaintFGup = New System.Windows.Forms.Button()
        Me.gbModV = New System.Windows.Forms.GroupBox()
        Me.ModelDisplay = New System.Windows.Forms.PictureBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.tbMString = New System.Windows.Forms.TextBox()
        Me.btnModelRight = New System.Windows.Forms.Button()
        Me.btnModelLeft = New System.Windows.Forms.Button()
        Me.gbTool = New System.Windows.Forms.GroupBox()
        Me.cbLabel = New System.Windows.Forms.CheckBox()
        Me.cbTriangle = New System.Windows.Forms.CheckBox()
        Me.cbLine = New System.Windows.Forms.CheckBox()
        Me.cbPrism = New System.Windows.Forms.CheckBox()
        Me.cbComp = New System.Windows.Forms.CheckBox()
        Me.cbSquare = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.tbPeakVZ = New System.Windows.Forms.TextBox()
        Me.tbPeakVY = New System.Windows.Forms.TextBox()
        Me.tbPeakVX = New System.Windows.Forms.TextBox()
        Me.btnPeakXup = New System.Windows.Forms.Button()
        Me.btnPeakXdown = New System.Windows.Forms.Button()
        Me.btnPeakYdown = New System.Windows.Forms.Button()
        Me.btnPeakYup = New System.Windows.Forms.Button()
        Me.btnPeakZdown = New System.Windows.Forms.Button()
        Me.btnPeakZup = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cbMacro = New System.Windows.Forms.CheckBox()
        Me.cbMicro = New System.Windows.Forms.CheckBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.tbMacroV = New System.Windows.Forms.TextBox()
        Me.tbMicroV = New System.Windows.Forms.TextBox()
        Me.btnMicroup = New System.Windows.Forms.Button()
        Me.btnMicrodown = New System.Windows.Forms.Button()
        Me.btnMacrodown = New System.Windows.Forms.Button()
        Me.btnMacroup = New System.Windows.Forms.Button()
        Me.gbTranslate = New System.Windows.Forms.GroupBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.tbTranslateVZ = New System.Windows.Forms.TextBox()
        Me.tbTranslateVY = New System.Windows.Forms.TextBox()
        Me.tbTranslateVX = New System.Windows.Forms.TextBox()
        Me.btnTranslateXup = New System.Windows.Forms.Button()
        Me.btnTranslateXdown = New System.Windows.Forms.Button()
        Me.btnTranslateYdown = New System.Windows.Forms.Button()
        Me.btnTranslateYup = New System.Windows.Forms.Button()
        Me.btnTranslateZdown = New System.Windows.Forms.Button()
        Me.btnTranslateZup = New System.Windows.Forms.Button()
        Me.gbAdjust = New System.Windows.Forms.GroupBox()
        Me.btnAdjustARight = New System.Windows.Forms.Button()
        Me.btnAdjustALeft = New System.Windows.Forms.Button()
        Me.tbAdjustMacro = New System.Windows.Forms.TextBox()
        Me.tbAdjustMicro = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.tbAdjustSelect = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.tbAdjustTotal = New System.Windows.Forms.TextBox()
        Me.btnAdjustVright = New System.Windows.Forms.Button()
        Me.btnAdjustVleft = New System.Windows.Forms.Button()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.tbAdjustVZ = New System.Windows.Forms.TextBox()
        Me.tbAdjustVY = New System.Windows.Forms.TextBox()
        Me.tbAdjustVX = New System.Windows.Forms.TextBox()
        Me.btnAdjustXup = New System.Windows.Forms.Button()
        Me.btnAdjustXdown = New System.Windows.Forms.Button()
        Me.btnAdjustYdown = New System.Windows.Forms.Button()
        Me.btnAdjustYup = New System.Windows.Forms.Button()
        Me.btnAdjustZdown = New System.Windows.Forms.Button()
        Me.btnAdjustZup = New System.Windows.Forms.Button()
        Me.gbSpin = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.tbSpinVZ = New System.Windows.Forms.TextBox()
        Me.tbSpinVY = New System.Windows.Forms.TextBox()
        Me.tbSpinVX = New System.Windows.Forms.TextBox()
        Me.btnSpinXup = New System.Windows.Forms.Button()
        Me.btnSpinXdown = New System.Windows.Forms.Button()
        Me.btnSpinYdown = New System.Windows.Forms.Button()
        Me.btnSpinYup = New System.Windows.Forms.Button()
        Me.btnSpinZdown = New System.Windows.Forms.Button()
        Me.btnSpinZup = New System.Windows.Forms.Button()
        Me.gbRadius = New System.Windows.Forms.GroupBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.tbRadiusV = New System.Windows.Forms.TextBox()
        Me.btnRadiusRup = New System.Windows.Forms.Button()
        Me.btnRadiusRdown = New System.Windows.Forms.Button()
        Me.gbMeasure = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbMeasureVZ = New System.Windows.Forms.TextBox()
        Me.tbMeasureVY = New System.Windows.Forms.TextBox()
        Me.tbMeasureVX = New System.Windows.Forms.TextBox()
        Me.btnMeasureXup = New System.Windows.Forms.Button()
        Me.btnMeasureXdown = New System.Windows.Forms.Button()
        Me.btnMeasureYdown = New System.Windows.Forms.Button()
        Me.btnMeasureYup = New System.Windows.Forms.Button()
        Me.btnMeasureZdown = New System.Windows.Forms.Button()
        Me.btnMeasureZup = New System.Windows.Forms.Button()
        Me.gbPaint = New System.Windows.Forms.GroupBox()
        Me.btnColorSwitchB = New System.Windows.Forms.Button()
        Me.btnColorSwitchG = New System.Windows.Forms.Button()
        Me.btnColorSwitchR = New System.Windows.Forms.Button()
        Me.btnColorSwitchA = New System.Windows.Forms.Button()
        Me.cbDrawmesh = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbPaintVB = New System.Windows.Forms.TextBox()
        Me.btnPaintBdown = New System.Windows.Forms.Button()
        Me.btnPaintBup = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbPaintVG = New System.Windows.Forms.TextBox()
        Me.tbPaintVR = New System.Windows.Forms.TextBox()
        Me.tbPaintVA = New System.Windows.Forms.TextBox()
        Me.btnPaintAup = New System.Windows.Forms.Button()
        Me.btnPaintAdown = New System.Windows.Forms.Button()
        Me.btnPaintRdown = New System.Windows.Forms.Button()
        Me.btnPaintRup = New System.Windows.Forms.Button()
        Me.btnPaintGdown = New System.Windows.Forms.Button()
        Me.btnPaintGup = New System.Windows.Forms.Button()
        Me.gbOrigin = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbOriginVZ = New System.Windows.Forms.TextBox()
        Me.tbOriginVY = New System.Windows.Forms.TextBox()
        Me.tbOriginVX = New System.Windows.Forms.TextBox()
        Me.btnOriginXup = New System.Windows.Forms.Button()
        Me.btnOriginXdown = New System.Windows.Forms.Button()
        Me.btnOriginYdown = New System.Windows.Forms.Button()
        Me.btnOriginYup = New System.Windows.Forms.Button()
        Me.btnOriginZdown = New System.Windows.Forms.Button()
        Me.btnOriginZup = New System.Windows.Forms.Button()
        Me.tbLog = New System.Windows.Forms.TextBox()
        Me.pViewControl = New System.Windows.Forms.Panel()
        Me.tbLabel = New System.Windows.Forms.TextBox()
        Me.gbGhost = New System.Windows.Forms.GroupBox()
        Me.cbLockZ = New System.Windows.Forms.CheckBox()
        Me.cbLockY = New System.Windows.Forms.CheckBox()
        Me.cbLockX = New System.Windows.Forms.CheckBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.btnGhostXright = New System.Windows.Forms.Button()
        Me.btnGhostXleft = New System.Windows.Forms.Button()
        Me.btnGhostYleft = New System.Windows.Forms.Button()
        Me.btnGhostYright = New System.Windows.Forms.Button()
        Me.btnGhostZleft = New System.Windows.Forms.Button()
        Me.btnGhostZright = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.btnGhostXup = New System.Windows.Forms.Button()
        Me.btnGhostXdown = New System.Windows.Forms.Button()
        Me.btnGhostYdown = New System.Windows.Forms.Button()
        Me.btnGhostYup = New System.Windows.Forms.Button()
        Me.btnGhostZdown = New System.Windows.Forms.Button()
        Me.btnGhostZup = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.btnZoomOut = New System.Windows.Forms.Button()
        Me.btnZoomIn = New System.Windows.Forms.Button()
        Me.btnCamSave = New System.Windows.Forms.Button()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.btnCamShiftDown = New System.Windows.Forms.Button()
        Me.btnCamShiftUp = New System.Windows.Forms.Button()
        Me.btnCamShiftRight = New System.Windows.Forms.Button()
        Me.btnCamShiftLeft = New System.Windows.Forms.Button()
        Me.btnCamTarget = New System.Windows.Forms.Button()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.btnViewdown = New System.Windows.Forms.Button()
        Me.btnViewup = New System.Windows.Forms.Button()
        Me.btnViewright = New System.Windows.Forms.Button()
        Me.btnViewleft = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cbAxisLines = New System.Windows.Forms.CheckBox()
        Me.tbGridDim = New System.Windows.Forms.TextBox()
        Me.tbGridSize = New System.Windows.Forms.TextBox()
        Me.btnGridSizeDown = New System.Windows.Forms.Button()
        Me.btnGridSizeUp = New System.Windows.Forms.Button()
        Me.btnGridDimDown = New System.Windows.Forms.Button()
        Me.btnGridDimUp = New System.Windows.Forms.Button()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.cbGridYZ = New System.Windows.Forms.CheckBox()
        Me.cbGridXY = New System.Windows.Forms.CheckBox()
        Me.cbGridXZ = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnUndo = New System.Windows.Forms.Button()
        Me.btnStep = New System.Windows.Forms.Button()
        Me.btnPress = New System.Windows.Forms.Button()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.btnRedo = New System.Windows.Forms.Button()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StyleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForeColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabelFontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XZTileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XYTileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YZTileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbApplySpin = New System.Windows.Forms.CheckBox()
        Me.cbApplyOrbit = New System.Windows.Forms.CheckBox()
        Me.FrameInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.MainDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pControl.SuspendLayout()
        Me.gbPaintFill.SuspendLayout()
        Me.gbModV.SuspendLayout()
        CType(Me.ModelDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbTool.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbTranslate.SuspendLayout()
        Me.gbAdjust.SuspendLayout()
        Me.gbSpin.SuspendLayout()
        Me.gbRadius.SuspendLayout()
        Me.gbMeasure.SuspendLayout()
        Me.gbPaint.SuspendLayout()
        Me.gbOrigin.SuspendLayout()
        Me.pViewControl.SuspendLayout()
        Me.gbGhost.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainDisplay
        '
        Me.MainDisplay.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MainDisplay.BackColor = System.Drawing.Color.Black
        Me.MainDisplay.Location = New System.Drawing.Point(4, 28)
        Me.MainDisplay.Name = "MainDisplay"
        Me.MainDisplay.Size = New System.Drawing.Size(831, 410)
        Me.MainDisplay.TabIndex = 13
        Me.MainDisplay.TabStop = False
        '
        'gPress
        '
        Me.gPress.Enabled = True
        '
        'pControl
        '
        Me.pControl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pControl.BackColor = System.Drawing.Color.Black
        Me.pControl.Controls.Add(Me.gbPaintFill)
        Me.pControl.Controls.Add(Me.gbModV)
        Me.pControl.Controls.Add(Me.gbTool)
        Me.pControl.Controls.Add(Me.GroupBox2)
        Me.pControl.Controls.Add(Me.GroupBox1)
        Me.pControl.Controls.Add(Me.gbTranslate)
        Me.pControl.Controls.Add(Me.gbAdjust)
        Me.pControl.Controls.Add(Me.gbSpin)
        Me.pControl.Controls.Add(Me.gbRadius)
        Me.pControl.Controls.Add(Me.gbMeasure)
        Me.pControl.Controls.Add(Me.gbPaint)
        Me.pControl.Controls.Add(Me.gbOrigin)
        Me.pControl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.pControl.Location = New System.Drawing.Point(839, 24)
        Me.pControl.Name = "pControl"
        Me.pControl.Size = New System.Drawing.Size(227, 490)
        Me.pControl.TabIndex = 14
        '
        'gbPaintFill
        '
        Me.gbPaintFill.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPaintFill.Controls.Add(Me.cbFillplane)
        Me.gbPaintFill.Controls.Add(Me.btnColorSwitchFB)
        Me.gbPaintFill.Controls.Add(Me.btnColorSwitchFG)
        Me.gbPaintFill.Controls.Add(Me.btnColorSwitchFR)
        Me.gbPaintFill.Controls.Add(Me.btnColorSwitchFA)
        Me.gbPaintFill.Controls.Add(Me.Label60)
        Me.gbPaintFill.Controls.Add(Me.tbPaintVFB)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFBdown)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFBup)
        Me.gbPaintFill.Controls.Add(Me.Label81)
        Me.gbPaintFill.Controls.Add(Me.Label82)
        Me.gbPaintFill.Controls.Add(Me.Label83)
        Me.gbPaintFill.Controls.Add(Me.Label84)
        Me.gbPaintFill.Controls.Add(Me.Label85)
        Me.gbPaintFill.Controls.Add(Me.Label86)
        Me.gbPaintFill.Controls.Add(Me.tbPaintVFG)
        Me.gbPaintFill.Controls.Add(Me.tbPaintVFR)
        Me.gbPaintFill.Controls.Add(Me.tbPaintVFA)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFAup)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFAdown)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFRdown)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFRup)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFGdown)
        Me.gbPaintFill.Controls.Add(Me.btnPaintFGup)
        Me.gbPaintFill.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbPaintFill.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPaintFill.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbPaintFill.Location = New System.Drawing.Point(132, 236)
        Me.gbPaintFill.Margin = New System.Windows.Forms.Padding(1)
        Me.gbPaintFill.Name = "gbPaintFill"
        Me.gbPaintFill.Padding = New System.Windows.Forms.Padding(1)
        Me.gbPaintFill.Size = New System.Drawing.Size(88, 91)
        Me.gbPaintFill.TabIndex = 52
        Me.gbPaintFill.TabStop = False
        Me.gbPaintFill.Text = "Paint"
        '
        'cbFillplane
        '
        Me.cbFillplane.AutoSize = True
        Me.cbFillplane.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbFillplane.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbFillplane.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbFillplane.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbFillplane.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbFillplane.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbFillplane.ForeColor = System.Drawing.Color.LightBlue
        Me.cbFillplane.Location = New System.Drawing.Point(6, 74)
        Me.cbFillplane.Name = "cbFillplane"
        Me.cbFillplane.Size = New System.Drawing.Size(71, 13)
        Me.cbFillplane.TabIndex = 34
        Me.cbFillplane.Text = "Fill Plane"
        Me.cbFillplane.UseVisualStyleBackColor = True
        '
        'btnColorSwitchFB
        '
        Me.btnColorSwitchFB.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchFB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchFB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchFB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchFB.Location = New System.Drawing.Point(40, 61)
        Me.btnColorSwitchFB.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchFB.Name = "btnColorSwitchFB"
        Me.btnColorSwitchFB.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchFB.TabIndex = 33
        Me.btnColorSwitchFB.UseVisualStyleBackColor = True
        '
        'btnColorSwitchFG
        '
        Me.btnColorSwitchFG.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchFG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchFG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchFG.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchFG.Location = New System.Drawing.Point(40, 49)
        Me.btnColorSwitchFG.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchFG.Name = "btnColorSwitchFG"
        Me.btnColorSwitchFG.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchFG.TabIndex = 32
        Me.btnColorSwitchFG.UseVisualStyleBackColor = True
        '
        'btnColorSwitchFR
        '
        Me.btnColorSwitchFR.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchFR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchFR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchFR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchFR.Location = New System.Drawing.Point(40, 37)
        Me.btnColorSwitchFR.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchFR.Name = "btnColorSwitchFR"
        Me.btnColorSwitchFR.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchFR.TabIndex = 31
        Me.btnColorSwitchFR.UseVisualStyleBackColor = True
        '
        'btnColorSwitchFA
        '
        Me.btnColorSwitchFA.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchFA.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchFA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchFA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchFA.Location = New System.Drawing.Point(40, 25)
        Me.btnColorSwitchFA.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchFA.Name = "btnColorSwitchFA"
        Me.btnColorSwitchFA.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchFA.TabIndex = 30
        Me.btnColorSwitchFA.UseVisualStyleBackColor = True
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label60.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.LightBlue
        Me.Label60.Location = New System.Drawing.Point(2, 61)
        Me.Label60.Margin = New System.Windows.Forms.Padding(1)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(11, 10)
        Me.Label60.TabIndex = 27
        Me.Label60.Text = "B"
        '
        'tbPaintVFB
        '
        Me.tbPaintVFB.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVFB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVFB.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVFB.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVFB.Location = New System.Drawing.Point(14, 61)
        Me.tbPaintVFB.Multiline = True
        Me.tbPaintVFB.Name = "tbPaintVFB"
        Me.tbPaintVFB.ReadOnly = True
        Me.tbPaintVFB.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVFB.TabIndex = 26
        Me.tbPaintVFB.Text = "255"
        Me.tbPaintVFB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPaintFBdown
        '
        Me.btnPaintFBdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFBdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFBdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFBdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFBdown.Location = New System.Drawing.Point(62, 61)
        Me.btnPaintFBdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFBdown.Name = "btnPaintFBdown"
        Me.btnPaintFBdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFBdown.TabIndex = 25
        Me.btnPaintFBdown.UseVisualStyleBackColor = True
        '
        'btnPaintFBup
        '
        Me.btnPaintFBup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFBup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFBup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFBup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFBup.Location = New System.Drawing.Point(74, 61)
        Me.btnPaintFBup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFBup.Name = "btnPaintFBup"
        Me.btnPaintFBup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFBup.TabIndex = 24
        Me.btnPaintFBup.UseVisualStyleBackColor = True
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label81.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label81.ForeColor = System.Drawing.Color.LightBlue
        Me.Label81.Location = New System.Drawing.Point(74, 12)
        Me.Label81.Margin = New System.Windows.Forms.Padding(1)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(12, 10)
        Me.Label81.TabIndex = 23
        Me.Label81.Text = "ñ"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label82.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label82.ForeColor = System.Drawing.Color.LightBlue
        Me.Label82.Location = New System.Drawing.Point(61, 13)
        Me.Label82.Margin = New System.Windows.Forms.Padding(1)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(12, 10)
        Me.Label82.TabIndex = 22
        Me.Label82.Text = "ò"
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label83.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.ForeColor = System.Drawing.Color.LightBlue
        Me.Label83.Location = New System.Drawing.Point(10, 12)
        Me.Label83.Margin = New System.Windows.Forms.Padding(1)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(29, 10)
        Me.Label83.TabIndex = 21
        Me.Label83.Text = "Fill"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label84.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.ForeColor = System.Drawing.Color.LightBlue
        Me.Label84.Location = New System.Drawing.Point(2, 49)
        Me.Label84.Margin = New System.Windows.Forms.Padding(1)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(11, 10)
        Me.Label84.TabIndex = 20
        Me.Label84.Text = "G"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label85.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.Color.LightBlue
        Me.Label85.Location = New System.Drawing.Point(2, 37)
        Me.Label85.Margin = New System.Windows.Forms.Padding(1)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(11, 10)
        Me.Label85.TabIndex = 19
        Me.Label85.Text = "R"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label86.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.ForeColor = System.Drawing.Color.LightBlue
        Me.Label86.Location = New System.Drawing.Point(2, 25)
        Me.Label86.Margin = New System.Windows.Forms.Padding(1)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(11, 10)
        Me.Label86.TabIndex = 18
        Me.Label86.Text = "A"
        '
        'tbPaintVFG
        '
        Me.tbPaintVFG.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVFG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVFG.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVFG.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVFG.Location = New System.Drawing.Point(14, 49)
        Me.tbPaintVFG.Multiline = True
        Me.tbPaintVFG.Name = "tbPaintVFG"
        Me.tbPaintVFG.ReadOnly = True
        Me.tbPaintVFG.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVFG.TabIndex = 17
        Me.tbPaintVFG.Text = "255"
        Me.tbPaintVFG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPaintVFR
        '
        Me.tbPaintVFR.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVFR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVFR.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVFR.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVFR.Location = New System.Drawing.Point(14, 37)
        Me.tbPaintVFR.Multiline = True
        Me.tbPaintVFR.Name = "tbPaintVFR"
        Me.tbPaintVFR.ReadOnly = True
        Me.tbPaintVFR.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVFR.TabIndex = 16
        Me.tbPaintVFR.Text = "255"
        Me.tbPaintVFR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPaintVFA
        '
        Me.tbPaintVFA.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVFA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVFA.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVFA.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVFA.Location = New System.Drawing.Point(14, 25)
        Me.tbPaintVFA.Multiline = True
        Me.tbPaintVFA.Name = "tbPaintVFA"
        Me.tbPaintVFA.ReadOnly = True
        Me.tbPaintVFA.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVFA.TabIndex = 15
        Me.tbPaintVFA.Text = "255"
        Me.tbPaintVFA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPaintFAup
        '
        Me.btnPaintFAup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFAup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFAup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFAup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFAup.Location = New System.Drawing.Point(74, 25)
        Me.btnPaintFAup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFAup.Name = "btnPaintFAup"
        Me.btnPaintFAup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFAup.TabIndex = 5
        Me.btnPaintFAup.UseVisualStyleBackColor = True
        '
        'btnPaintFAdown
        '
        Me.btnPaintFAdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFAdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFAdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFAdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFAdown.Location = New System.Drawing.Point(62, 25)
        Me.btnPaintFAdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFAdown.Name = "btnPaintFAdown"
        Me.btnPaintFAdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFAdown.TabIndex = 4
        Me.btnPaintFAdown.UseVisualStyleBackColor = True
        '
        'btnPaintFRdown
        '
        Me.btnPaintFRdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFRdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFRdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFRdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFRdown.Location = New System.Drawing.Point(62, 37)
        Me.btnPaintFRdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFRdown.Name = "btnPaintFRdown"
        Me.btnPaintFRdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFRdown.TabIndex = 3
        Me.btnPaintFRdown.UseVisualStyleBackColor = True
        '
        'btnPaintFRup
        '
        Me.btnPaintFRup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFRup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFRup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFRup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFRup.Location = New System.Drawing.Point(74, 37)
        Me.btnPaintFRup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFRup.Name = "btnPaintFRup"
        Me.btnPaintFRup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFRup.TabIndex = 2
        Me.btnPaintFRup.UseVisualStyleBackColor = True
        '
        'btnPaintFGdown
        '
        Me.btnPaintFGdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFGdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFGdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFGdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFGdown.Location = New System.Drawing.Point(62, 49)
        Me.btnPaintFGdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFGdown.Name = "btnPaintFGdown"
        Me.btnPaintFGdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFGdown.TabIndex = 1
        Me.btnPaintFGdown.UseVisualStyleBackColor = True
        '
        'btnPaintFGup
        '
        Me.btnPaintFGup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintFGup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintFGup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintFGup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintFGup.Location = New System.Drawing.Point(74, 49)
        Me.btnPaintFGup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintFGup.Name = "btnPaintFGup"
        Me.btnPaintFGup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintFGup.TabIndex = 0
        Me.btnPaintFGup.UseVisualStyleBackColor = True
        '
        'gbModV
        '
        Me.gbModV.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbModV.BackColor = System.Drawing.Color.Black
        Me.gbModV.Controls.Add(Me.ModelDisplay)
        Me.gbModV.Controls.Add(Me.Label79)
        Me.gbModV.Controls.Add(Me.Label80)
        Me.gbModV.Controls.Add(Me.tbMString)
        Me.gbModV.Controls.Add(Me.btnModelRight)
        Me.gbModV.Controls.Add(Me.btnModelLeft)
        Me.gbModV.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbModV.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbModV.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbModV.Location = New System.Drawing.Point(6, 4)
        Me.gbModV.Margin = New System.Windows.Forms.Padding(1)
        Me.gbModV.Name = "gbModV"
        Me.gbModV.Padding = New System.Windows.Forms.Padding(1)
        Me.gbModV.Size = New System.Drawing.Size(214, 43)
        Me.gbModV.TabIndex = 51
        Me.gbModV.TabStop = False
        Me.gbModV.Text = "Model"
        '
        'ModelDisplay
        '
        Me.ModelDisplay.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ModelDisplay.BackColor = System.Drawing.Color.Black
        Me.ModelDisplay.Location = New System.Drawing.Point(4, 12)
        Me.ModelDisplay.Name = "ModelDisplay"
        Me.ModelDisplay.Size = New System.Drawing.Size(206, 10)
        Me.ModelDisplay.TabIndex = 65
        Me.ModelDisplay.TabStop = False
        '
        'Label79
        '
        Me.Label79.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label79.AutoSize = True
        Me.Label79.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label79.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label79.ForeColor = System.Drawing.Color.LightBlue
        Me.Label79.Location = New System.Drawing.Point(3, 27)
        Me.Label79.Margin = New System.Windows.Forms.Padding(1)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(13, 10)
        Me.Label79.TabIndex = 63
        Me.Label79.Text = "ï"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label80
        '
        Me.Label80.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label80.AutoSize = True
        Me.Label80.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label80.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label80.ForeColor = System.Drawing.Color.LightBlue
        Me.Label80.Location = New System.Drawing.Point(199, 28)
        Me.Label80.Margin = New System.Windows.Forms.Padding(1)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(13, 10)
        Me.Label80.TabIndex = 62
        Me.Label80.Text = "ð"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbMString
        '
        Me.tbMString.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.tbMString.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMString.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMString.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMString.Location = New System.Drawing.Point(32, 26)
        Me.tbMString.Multiline = True
        Me.tbMString.Name = "tbMString"
        Me.tbMString.ReadOnly = True
        Me.tbMString.Size = New System.Drawing.Size(151, 12)
        Me.tbMString.TabIndex = 60
        Me.tbMString.Text = "0000"
        Me.tbMString.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnModelRight
        '
        Me.btnModelRight.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnModelRight.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnModelRight.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnModelRight.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnModelRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModelRight.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnModelRight.ForeColor = System.Drawing.Color.LightBlue
        Me.btnModelRight.Location = New System.Drawing.Point(186, 26)
        Me.btnModelRight.Margin = New System.Windows.Forms.Padding(1)
        Me.btnModelRight.Name = "btnModelRight"
        Me.btnModelRight.Size = New System.Drawing.Size(12, 12)
        Me.btnModelRight.TabIndex = 59
        Me.btnModelRight.UseVisualStyleBackColor = True
        '
        'btnModelLeft
        '
        Me.btnModelLeft.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnModelLeft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnModelLeft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnModelLeft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnModelLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModelLeft.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnModelLeft.ForeColor = System.Drawing.Color.LightBlue
        Me.btnModelLeft.Location = New System.Drawing.Point(16, 26)
        Me.btnModelLeft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnModelLeft.Name = "btnModelLeft"
        Me.btnModelLeft.Size = New System.Drawing.Size(12, 12)
        Me.btnModelLeft.TabIndex = 58
        Me.btnModelLeft.UseVisualStyleBackColor = True
        '
        'gbTool
        '
        Me.gbTool.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbTool.BackColor = System.Drawing.Color.Black
        Me.gbTool.Controls.Add(Me.cbLabel)
        Me.gbTool.Controls.Add(Me.cbTriangle)
        Me.gbTool.Controls.Add(Me.cbLine)
        Me.gbTool.Controls.Add(Me.cbPrism)
        Me.gbTool.Controls.Add(Me.cbComp)
        Me.gbTool.Controls.Add(Me.cbSquare)
        Me.gbTool.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbTool.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbTool.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbTool.Location = New System.Drawing.Point(6, 49)
        Me.gbTool.Margin = New System.Windows.Forms.Padding(1)
        Me.gbTool.Name = "gbTool"
        Me.gbTool.Padding = New System.Windows.Forms.Padding(1)
        Me.gbTool.Size = New System.Drawing.Size(214, 49)
        Me.gbTool.TabIndex = 30
        Me.gbTool.TabStop = False
        Me.gbTool.Text = "Tool"
        '
        'cbLabel
        '
        Me.cbLabel.AutoSize = True
        Me.cbLabel.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbLabel.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbLabel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbLabel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbLabel.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbLabel.ForeColor = System.Drawing.Color.LightBlue
        Me.cbLabel.Location = New System.Drawing.Point(151, 31)
        Me.cbLabel.Name = "cbLabel"
        Me.cbLabel.Size = New System.Drawing.Size(46, 13)
        Me.cbLabel.TabIndex = 5
        Me.cbLabel.Text = "Label"
        Me.cbLabel.UseVisualStyleBackColor = True
        '
        'cbTriangle
        '
        Me.cbTriangle.AutoSize = True
        Me.cbTriangle.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbTriangle.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbTriangle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbTriangle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbTriangle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbTriangle.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbTriangle.ForeColor = System.Drawing.Color.LightBlue
        Me.cbTriangle.Location = New System.Drawing.Point(77, 31)
        Me.cbTriangle.Name = "cbTriangle"
        Me.cbTriangle.Size = New System.Drawing.Size(61, 13)
        Me.cbTriangle.TabIndex = 4
        Me.cbTriangle.Text = "Triangle"
        Me.cbTriangle.UseVisualStyleBackColor = True
        '
        'cbLine
        '
        Me.cbLine.AutoSize = True
        Me.cbLine.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbLine.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbLine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbLine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbLine.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbLine.ForeColor = System.Drawing.Color.LightBlue
        Me.cbLine.Location = New System.Drawing.Point(10, 13)
        Me.cbLine.Name = "cbLine"
        Me.cbLine.Size = New System.Drawing.Size(41, 13)
        Me.cbLine.TabIndex = 3
        Me.cbLine.Text = "Line"
        Me.cbLine.UseVisualStyleBackColor = True
        '
        'cbPrism
        '
        Me.cbPrism.AutoSize = True
        Me.cbPrism.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbPrism.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbPrism.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbPrism.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbPrism.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbPrism.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbPrism.ForeColor = System.Drawing.Color.LightBlue
        Me.cbPrism.Location = New System.Drawing.Point(151, 13)
        Me.cbPrism.Name = "cbPrism"
        Me.cbPrism.Size = New System.Drawing.Size(46, 13)
        Me.cbPrism.TabIndex = 2
        Me.cbPrism.Text = "Prism"
        Me.cbPrism.UseVisualStyleBackColor = True
        '
        'cbComp
        '
        Me.cbComp.AutoSize = True
        Me.cbComp.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbComp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbComp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbComp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbComp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbComp.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbComp.ForeColor = System.Drawing.Color.LightBlue
        Me.cbComp.Location = New System.Drawing.Point(77, 13)
        Me.cbComp.Name = "cbComp"
        Me.cbComp.Size = New System.Drawing.Size(56, 13)
        Me.cbComp.TabIndex = 1
        Me.cbComp.Text = "Compass"
        Me.cbComp.UseVisualStyleBackColor = True
        '
        'cbSquare
        '
        Me.cbSquare.AutoSize = True
        Me.cbSquare.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbSquare.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbSquare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbSquare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbSquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbSquare.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbSquare.ForeColor = System.Drawing.Color.LightBlue
        Me.cbSquare.Location = New System.Drawing.Point(10, 31)
        Me.cbSquare.Name = "cbSquare"
        Me.cbSquare.Size = New System.Drawing.Size(51, 13)
        Me.cbSquare.TabIndex = 0
        Me.cbSquare.Text = "Square"
        Me.cbSquare.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Label51)
        Me.GroupBox2.Controls.Add(Me.Label54)
        Me.GroupBox2.Controls.Add(Me.Label55)
        Me.GroupBox2.Controls.Add(Me.Label56)
        Me.GroupBox2.Controls.Add(Me.Label57)
        Me.GroupBox2.Controls.Add(Me.Label58)
        Me.GroupBox2.Controls.Add(Me.tbPeakVZ)
        Me.GroupBox2.Controls.Add(Me.tbPeakVY)
        Me.GroupBox2.Controls.Add(Me.tbPeakVX)
        Me.GroupBox2.Controls.Add(Me.btnPeakXup)
        Me.GroupBox2.Controls.Add(Me.btnPeakXdown)
        Me.GroupBox2.Controls.Add(Me.btnPeakYdown)
        Me.GroupBox2.Controls.Add(Me.btnPeakYup)
        Me.GroupBox2.Controls.Add(Me.btnPeakZdown)
        Me.GroupBox2.Controls.Add(Me.btnPeakZup)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox2.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox2.Location = New System.Drawing.Point(6, 279)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Size = New System.Drawing.Size(122, 65)
        Me.GroupBox2.TabIndex = 50
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Peak"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label51.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.LightBlue
        Me.Label51.Location = New System.Drawing.Point(103, 14)
        Me.Label51.Margin = New System.Windows.Forms.Padding(1)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(12, 10)
        Me.Label51.TabIndex = 23
        Me.Label51.Text = "ñ"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label54.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.LightBlue
        Me.Label54.Location = New System.Drawing.Point(82, 15)
        Me.Label54.Margin = New System.Windows.Forms.Padding(1)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(12, 10)
        Me.Label54.TabIndex = 22
        Me.Label54.Text = "ò"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label55.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.LightBlue
        Me.Label55.Location = New System.Drawing.Point(33, 13)
        Me.Label55.Margin = New System.Windows.Forms.Padding(1)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(29, 10)
        Me.Label55.TabIndex = 21
        Me.Label55.Text = "Line"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label56.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.LightBlue
        Me.Label56.Location = New System.Drawing.Point(4, 51)
        Me.Label56.Margin = New System.Windows.Forms.Padding(1)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(11, 10)
        Me.Label56.TabIndex = 20
        Me.Label56.Text = "Z"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label57.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.LightBlue
        Me.Label57.Location = New System.Drawing.Point(4, 39)
        Me.Label57.Margin = New System.Windows.Forms.Padding(1)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(11, 10)
        Me.Label57.TabIndex = 19
        Me.Label57.Text = "Y"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label58.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.LightBlue
        Me.Label58.Location = New System.Drawing.Point(4, 27)
        Me.Label58.Margin = New System.Windows.Forms.Padding(1)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(11, 10)
        Me.Label58.TabIndex = 18
        Me.Label58.Text = "X"
        '
        'tbPeakVZ
        '
        Me.tbPeakVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPeakVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPeakVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPeakVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPeakVZ.Location = New System.Drawing.Point(19, 51)
        Me.tbPeakVZ.Multiline = True
        Me.tbPeakVZ.Name = "tbPeakVZ"
        Me.tbPeakVZ.ReadOnly = True
        Me.tbPeakVZ.Size = New System.Drawing.Size(55, 10)
        Me.tbPeakVZ.TabIndex = 17
        Me.tbPeakVZ.Text = "00000.000"
        Me.tbPeakVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPeakVY
        '
        Me.tbPeakVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPeakVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPeakVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPeakVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPeakVY.Location = New System.Drawing.Point(19, 39)
        Me.tbPeakVY.Multiline = True
        Me.tbPeakVY.Name = "tbPeakVY"
        Me.tbPeakVY.ReadOnly = True
        Me.tbPeakVY.Size = New System.Drawing.Size(55, 10)
        Me.tbPeakVY.TabIndex = 16
        Me.tbPeakVY.Text = "00000.000"
        Me.tbPeakVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPeakVX
        '
        Me.tbPeakVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPeakVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPeakVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPeakVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPeakVX.Location = New System.Drawing.Point(19, 27)
        Me.tbPeakVX.Multiline = True
        Me.tbPeakVX.Name = "tbPeakVX"
        Me.tbPeakVX.ReadOnly = True
        Me.tbPeakVX.Size = New System.Drawing.Size(55, 10)
        Me.tbPeakVX.TabIndex = 15
        Me.tbPeakVX.Text = "00000.000"
        Me.tbPeakVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPeakXup
        '
        Me.btnPeakXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakXup.Location = New System.Drawing.Point(99, 27)
        Me.btnPeakXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakXup.Name = "btnPeakXup"
        Me.btnPeakXup.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakXup.TabIndex = 5
        Me.btnPeakXup.UseVisualStyleBackColor = True
        '
        'btnPeakXdown
        '
        Me.btnPeakXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakXdown.Location = New System.Drawing.Point(77, 27)
        Me.btnPeakXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakXdown.Name = "btnPeakXdown"
        Me.btnPeakXdown.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakXdown.TabIndex = 4
        Me.btnPeakXdown.UseVisualStyleBackColor = True
        '
        'btnPeakYdown
        '
        Me.btnPeakYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakYdown.Location = New System.Drawing.Point(77, 39)
        Me.btnPeakYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakYdown.Name = "btnPeakYdown"
        Me.btnPeakYdown.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakYdown.TabIndex = 3
        Me.btnPeakYdown.UseVisualStyleBackColor = True
        '
        'btnPeakYup
        '
        Me.btnPeakYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakYup.Location = New System.Drawing.Point(99, 39)
        Me.btnPeakYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakYup.Name = "btnPeakYup"
        Me.btnPeakYup.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakYup.TabIndex = 2
        Me.btnPeakYup.UseVisualStyleBackColor = True
        '
        'btnPeakZdown
        '
        Me.btnPeakZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakZdown.Location = New System.Drawing.Point(77, 51)
        Me.btnPeakZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakZdown.Name = "btnPeakZdown"
        Me.btnPeakZdown.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakZdown.TabIndex = 1
        Me.btnPeakZdown.UseVisualStyleBackColor = True
        '
        'btnPeakZup
        '
        Me.btnPeakZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPeakZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPeakZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPeakZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPeakZup.Location = New System.Drawing.Point(99, 51)
        Me.btnPeakZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPeakZup.Name = "btnPeakZup"
        Me.btnPeakZup.Size = New System.Drawing.Size(20, 10)
        Me.btnPeakZup.TabIndex = 0
        Me.btnPeakZup.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.cbMacro)
        Me.GroupBox1.Controls.Add(Me.cbMicro)
        Me.GroupBox1.Controls.Add(Me.Label52)
        Me.GroupBox1.Controls.Add(Me.Label53)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.Label50)
        Me.GroupBox1.Controls.Add(Me.tbMacroV)
        Me.GroupBox1.Controls.Add(Me.tbMicroV)
        Me.GroupBox1.Controls.Add(Me.btnMicroup)
        Me.GroupBox1.Controls.Add(Me.btnMicrodown)
        Me.GroupBox1.Controls.Add(Me.btnMacrodown)
        Me.GroupBox1.Controls.Add(Me.btnMacroup)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Location = New System.Drawing.Point(6, 100)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Size = New System.Drawing.Size(214, 42)
        Me.GroupBox1.TabIndex = 49
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Meter"
        '
        'cbMacro
        '
        Me.cbMacro.AutoSize = True
        Me.cbMacro.Checked = True
        Me.cbMacro.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbMacro.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbMacro.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbMacro.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbMacro.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbMacro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbMacro.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMacro.ForeColor = System.Drawing.Color.LightBlue
        Me.cbMacro.Location = New System.Drawing.Point(115, 12)
        Me.cbMacro.Name = "cbMacro"
        Me.cbMacro.Size = New System.Drawing.Size(46, 13)
        Me.cbMacro.TabIndex = 28
        Me.cbMacro.Text = "Macro"
        Me.cbMacro.UseVisualStyleBackColor = True
        '
        'cbMicro
        '
        Me.cbMicro.AutoSize = True
        Me.cbMicro.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbMicro.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbMicro.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbMicro.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbMicro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbMicro.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMicro.ForeColor = System.Drawing.Color.LightBlue
        Me.cbMicro.Location = New System.Drawing.Point(10, 12)
        Me.cbMicro.Name = "cbMicro"
        Me.cbMicro.Size = New System.Drawing.Size(46, 13)
        Me.cbMicro.TabIndex = 27
        Me.cbMicro.Text = "Micro"
        Me.cbMicro.UseVisualStyleBackColor = True
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label52.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.LightBlue
        Me.Label52.Location = New System.Drawing.Point(194, 14)
        Me.Label52.Margin = New System.Windows.Forms.Padding(1)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(12, 10)
        Me.Label52.TabIndex = 26
        Me.Label52.Text = "ñ"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label53.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.LightBlue
        Me.Label53.Location = New System.Drawing.Point(173, 15)
        Me.Label53.Margin = New System.Windows.Forms.Padding(1)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(12, 10)
        Me.Label53.TabIndex = 25
        Me.Label53.Text = "ò"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label49.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.LightBlue
        Me.Label49.Location = New System.Drawing.Point(89, 14)
        Me.Label49.Margin = New System.Windows.Forms.Padding(1)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(12, 10)
        Me.Label49.TabIndex = 23
        Me.Label49.Text = "ñ"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label50.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.LightBlue
        Me.Label50.Location = New System.Drawing.Point(68, 15)
        Me.Label50.Margin = New System.Windows.Forms.Padding(1)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(12, 10)
        Me.Label50.TabIndex = 22
        Me.Label50.Text = "ò"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbMacroV
        '
        Me.tbMacroV.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMacroV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMacroV.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMacroV.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMacroV.Location = New System.Drawing.Point(110, 27)
        Me.tbMacroV.Multiline = True
        Me.tbMacroV.Name = "tbMacroV"
        Me.tbMacroV.ReadOnly = True
        Me.tbMacroV.Size = New System.Drawing.Size(55, 10)
        Me.tbMacroV.TabIndex = 16
        Me.tbMacroV.Text = "00000.000"
        Me.tbMacroV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbMicroV
        '
        Me.tbMicroV.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMicroV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMicroV.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMicroV.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMicroV.Location = New System.Drawing.Point(5, 27)
        Me.tbMicroV.Multiline = True
        Me.tbMicroV.Name = "tbMicroV"
        Me.tbMicroV.ReadOnly = True
        Me.tbMicroV.Size = New System.Drawing.Size(55, 10)
        Me.tbMicroV.TabIndex = 15
        Me.tbMicroV.Text = "00000.000"
        Me.tbMicroV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnMicroup
        '
        Me.btnMicroup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMicroup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMicroup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMicroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMicroup.Location = New System.Drawing.Point(85, 27)
        Me.btnMicroup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMicroup.Name = "btnMicroup"
        Me.btnMicroup.Size = New System.Drawing.Size(20, 10)
        Me.btnMicroup.TabIndex = 5
        Me.btnMicroup.UseVisualStyleBackColor = True
        '
        'btnMicrodown
        '
        Me.btnMicrodown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMicrodown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMicrodown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMicrodown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMicrodown.Location = New System.Drawing.Point(63, 27)
        Me.btnMicrodown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMicrodown.Name = "btnMicrodown"
        Me.btnMicrodown.Size = New System.Drawing.Size(20, 10)
        Me.btnMicrodown.TabIndex = 4
        Me.btnMicrodown.UseVisualStyleBackColor = True
        '
        'btnMacrodown
        '
        Me.btnMacrodown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMacrodown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMacrodown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMacrodown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMacrodown.Location = New System.Drawing.Point(168, 27)
        Me.btnMacrodown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMacrodown.Name = "btnMacrodown"
        Me.btnMacrodown.Size = New System.Drawing.Size(20, 10)
        Me.btnMacrodown.TabIndex = 3
        Me.btnMacrodown.UseVisualStyleBackColor = True
        '
        'btnMacroup
        '
        Me.btnMacroup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMacroup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMacroup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMacroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMacroup.Location = New System.Drawing.Point(190, 27)
        Me.btnMacroup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMacroup.Name = "btnMacroup"
        Me.btnMacroup.Size = New System.Drawing.Size(20, 10)
        Me.btnMacroup.TabIndex = 2
        Me.btnMacroup.UseVisualStyleBackColor = True
        '
        'gbTranslate
        '
        Me.gbTranslate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbTranslate.Controls.Add(Me.cbApplyOrbit)
        Me.gbTranslate.Controls.Add(Me.Label43)
        Me.gbTranslate.Controls.Add(Me.Label44)
        Me.gbTranslate.Controls.Add(Me.Label45)
        Me.gbTranslate.Controls.Add(Me.Label46)
        Me.gbTranslate.Controls.Add(Me.Label47)
        Me.gbTranslate.Controls.Add(Me.Label48)
        Me.gbTranslate.Controls.Add(Me.tbTranslateVZ)
        Me.gbTranslate.Controls.Add(Me.tbTranslateVY)
        Me.gbTranslate.Controls.Add(Me.tbTranslateVX)
        Me.gbTranslate.Controls.Add(Me.btnTranslateXup)
        Me.gbTranslate.Controls.Add(Me.btnTranslateXdown)
        Me.gbTranslate.Controls.Add(Me.btnTranslateYdown)
        Me.gbTranslate.Controls.Add(Me.btnTranslateYup)
        Me.gbTranslate.Controls.Add(Me.btnTranslateZdown)
        Me.gbTranslate.Controls.Add(Me.btnTranslateZup)
        Me.gbTranslate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbTranslate.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbTranslate.ForeColor = System.Drawing.SystemColors.Control
        Me.gbTranslate.Location = New System.Drawing.Point(132, 408)
        Me.gbTranslate.Margin = New System.Windows.Forms.Padding(1)
        Me.gbTranslate.Name = "gbTranslate"
        Me.gbTranslate.Padding = New System.Windows.Forms.Padding(1)
        Me.gbTranslate.Size = New System.Drawing.Size(88, 77)
        Me.gbTranslate.TabIndex = 48
        Me.gbTranslate.TabStop = False
        Me.gbTranslate.Text = "Orbit"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label43.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.LightBlue
        Me.Label43.Location = New System.Drawing.Point(74, 11)
        Me.Label43.Margin = New System.Windows.Forms.Padding(1)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(12, 10)
        Me.Label43.TabIndex = 23
        Me.Label43.Text = "ñ"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label44.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.LightBlue
        Me.Label44.Location = New System.Drawing.Point(62, 12)
        Me.Label44.Margin = New System.Windows.Forms.Padding(1)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(12, 10)
        Me.Label44.TabIndex = 22
        Me.Label44.Text = "ò"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label45.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.LightBlue
        Me.Label45.Location = New System.Drawing.Point(17, 11)
        Me.Label45.Margin = New System.Windows.Forms.Padding(1)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(41, 10)
        Me.Label45.TabIndex = 21
        Me.Label45.Text = "Radian"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label46.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.LightBlue
        Me.Label46.Location = New System.Drawing.Point(2, 48)
        Me.Label46.Margin = New System.Windows.Forms.Padding(1)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(11, 10)
        Me.Label46.TabIndex = 20
        Me.Label46.Text = "Z"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label47.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.LightBlue
        Me.Label47.Location = New System.Drawing.Point(2, 36)
        Me.Label47.Margin = New System.Windows.Forms.Padding(1)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(11, 10)
        Me.Label47.TabIndex = 19
        Me.Label47.Text = "Y"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label48.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.LightBlue
        Me.Label48.Location = New System.Drawing.Point(2, 24)
        Me.Label48.Margin = New System.Windows.Forms.Padding(1)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(11, 10)
        Me.Label48.TabIndex = 18
        Me.Label48.Text = "X"
        '
        'tbTranslateVZ
        '
        Me.tbTranslateVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbTranslateVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbTranslateVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTranslateVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbTranslateVZ.Location = New System.Drawing.Point(14, 48)
        Me.tbTranslateVZ.Multiline = True
        Me.tbTranslateVZ.Name = "tbTranslateVZ"
        Me.tbTranslateVZ.ReadOnly = True
        Me.tbTranslateVZ.Size = New System.Drawing.Size(46, 10)
        Me.tbTranslateVZ.TabIndex = 17
        Me.tbTranslateVZ.Text = "255"
        Me.tbTranslateVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbTranslateVY
        '
        Me.tbTranslateVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbTranslateVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbTranslateVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTranslateVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbTranslateVY.Location = New System.Drawing.Point(14, 36)
        Me.tbTranslateVY.Multiline = True
        Me.tbTranslateVY.Name = "tbTranslateVY"
        Me.tbTranslateVY.ReadOnly = True
        Me.tbTranslateVY.Size = New System.Drawing.Size(46, 10)
        Me.tbTranslateVY.TabIndex = 16
        Me.tbTranslateVY.Text = "255"
        Me.tbTranslateVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbTranslateVX
        '
        Me.tbTranslateVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbTranslateVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbTranslateVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTranslateVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbTranslateVX.Location = New System.Drawing.Point(14, 24)
        Me.tbTranslateVX.Multiline = True
        Me.tbTranslateVX.Name = "tbTranslateVX"
        Me.tbTranslateVX.ReadOnly = True
        Me.tbTranslateVX.Size = New System.Drawing.Size(46, 10)
        Me.tbTranslateVX.TabIndex = 15
        Me.tbTranslateVX.Text = "255"
        Me.tbTranslateVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnTranslateXup
        '
        Me.btnTranslateXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateXup.Location = New System.Drawing.Point(74, 24)
        Me.btnTranslateXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateXup.Name = "btnTranslateXup"
        Me.btnTranslateXup.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateXup.TabIndex = 5
        Me.btnTranslateXup.UseVisualStyleBackColor = True
        '
        'btnTranslateXdown
        '
        Me.btnTranslateXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateXdown.Location = New System.Drawing.Point(62, 24)
        Me.btnTranslateXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateXdown.Name = "btnTranslateXdown"
        Me.btnTranslateXdown.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateXdown.TabIndex = 4
        Me.btnTranslateXdown.UseVisualStyleBackColor = True
        '
        'btnTranslateYdown
        '
        Me.btnTranslateYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateYdown.Location = New System.Drawing.Point(62, 36)
        Me.btnTranslateYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateYdown.Name = "btnTranslateYdown"
        Me.btnTranslateYdown.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateYdown.TabIndex = 3
        Me.btnTranslateYdown.UseVisualStyleBackColor = True
        '
        'btnTranslateYup
        '
        Me.btnTranslateYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateYup.Location = New System.Drawing.Point(74, 36)
        Me.btnTranslateYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateYup.Name = "btnTranslateYup"
        Me.btnTranslateYup.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateYup.TabIndex = 2
        Me.btnTranslateYup.UseVisualStyleBackColor = True
        '
        'btnTranslateZdown
        '
        Me.btnTranslateZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateZdown.Location = New System.Drawing.Point(62, 48)
        Me.btnTranslateZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateZdown.Name = "btnTranslateZdown"
        Me.btnTranslateZdown.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateZdown.TabIndex = 1
        Me.btnTranslateZdown.UseVisualStyleBackColor = True
        '
        'btnTranslateZup
        '
        Me.btnTranslateZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnTranslateZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnTranslateZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTranslateZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTranslateZup.Location = New System.Drawing.Point(74, 48)
        Me.btnTranslateZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnTranslateZup.Name = "btnTranslateZup"
        Me.btnTranslateZup.Size = New System.Drawing.Size(10, 10)
        Me.btnTranslateZup.TabIndex = 0
        Me.btnTranslateZup.UseVisualStyleBackColor = True
        '
        'gbAdjust
        '
        Me.gbAdjust.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbAdjust.Controls.Add(Me.btnAdjustARight)
        Me.gbAdjust.Controls.Add(Me.btnAdjustALeft)
        Me.gbAdjust.Controls.Add(Me.tbAdjustMacro)
        Me.gbAdjust.Controls.Add(Me.tbAdjustMicro)
        Me.gbAdjust.Controls.Add(Me.Label76)
        Me.gbAdjust.Controls.Add(Me.Label75)
        Me.gbAdjust.Controls.Add(Me.tbAdjustSelect)
        Me.gbAdjust.Controls.Add(Me.Label42)
        Me.gbAdjust.Controls.Add(Me.tbAdjustTotal)
        Me.gbAdjust.Controls.Add(Me.btnAdjustVright)
        Me.gbAdjust.Controls.Add(Me.btnAdjustVleft)
        Me.gbAdjust.Controls.Add(Me.Label36)
        Me.gbAdjust.Controls.Add(Me.Label37)
        Me.gbAdjust.Controls.Add(Me.Label38)
        Me.gbAdjust.Controls.Add(Me.Label39)
        Me.gbAdjust.Controls.Add(Me.Label40)
        Me.gbAdjust.Controls.Add(Me.Label41)
        Me.gbAdjust.Controls.Add(Me.tbAdjustVZ)
        Me.gbAdjust.Controls.Add(Me.tbAdjustVY)
        Me.gbAdjust.Controls.Add(Me.tbAdjustVX)
        Me.gbAdjust.Controls.Add(Me.btnAdjustXup)
        Me.gbAdjust.Controls.Add(Me.btnAdjustXdown)
        Me.gbAdjust.Controls.Add(Me.btnAdjustYdown)
        Me.gbAdjust.Controls.Add(Me.btnAdjustYup)
        Me.gbAdjust.Controls.Add(Me.btnAdjustZdown)
        Me.gbAdjust.Controls.Add(Me.btnAdjustZup)
        Me.gbAdjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbAdjust.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbAdjust.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbAdjust.Location = New System.Drawing.Point(6, 389)
        Me.gbAdjust.Margin = New System.Windows.Forms.Padding(1)
        Me.gbAdjust.Name = "gbAdjust"
        Me.gbAdjust.Padding = New System.Windows.Forms.Padding(1)
        Me.gbAdjust.Size = New System.Drawing.Size(122, 96)
        Me.gbAdjust.TabIndex = 47
        Me.gbAdjust.TabStop = False
        Me.gbAdjust.Text = "Adjust"
        '
        'btnAdjustARight
        '
        Me.btnAdjustARight.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustARight.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustARight.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustARight.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustARight.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnAdjustARight.ForeColor = System.Drawing.Color.LightBlue
        Me.btnAdjustARight.Location = New System.Drawing.Point(94, 19)
        Me.btnAdjustARight.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustARight.Name = "btnAdjustARight"
        Me.btnAdjustARight.Size = New System.Drawing.Size(12, 12)
        Me.btnAdjustARight.TabIndex = 57
        Me.btnAdjustARight.UseVisualStyleBackColor = True
        '
        'btnAdjustALeft
        '
        Me.btnAdjustALeft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustALeft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustALeft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustALeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustALeft.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnAdjustALeft.ForeColor = System.Drawing.Color.LightBlue
        Me.btnAdjustALeft.Location = New System.Drawing.Point(15, 19)
        Me.btnAdjustALeft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustALeft.Name = "btnAdjustALeft"
        Me.btnAdjustALeft.Size = New System.Drawing.Size(12, 12)
        Me.btnAdjustALeft.TabIndex = 56
        Me.btnAdjustALeft.UseVisualStyleBackColor = True
        '
        'tbAdjustMacro
        '
        Me.tbAdjustMacro.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustMacro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustMacro.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustMacro.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustMacro.Location = New System.Drawing.Point(30, 21)
        Me.tbAdjustMacro.Multiline = True
        Me.tbAdjustMacro.Name = "tbAdjustMacro"
        Me.tbAdjustMacro.ReadOnly = True
        Me.tbAdjustMacro.Size = New System.Drawing.Size(30, 11)
        Me.tbAdjustMacro.TabIndex = 55
        Me.tbAdjustMacro.Text = "0000"
        Me.tbAdjustMacro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbAdjustMicro
        '
        Me.tbAdjustMicro.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustMicro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustMicro.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustMicro.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustMicro.Location = New System.Drawing.Point(61, 21)
        Me.tbAdjustMicro.Multiline = True
        Me.tbAdjustMicro.Name = "tbAdjustMicro"
        Me.tbAdjustMicro.ReadOnly = True
        Me.tbAdjustMicro.Size = New System.Drawing.Size(30, 11)
        Me.tbAdjustMicro.TabIndex = 54
        Me.tbAdjustMicro.Text = "0000"
        Me.tbAdjustMicro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label76.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label76.ForeColor = System.Drawing.Color.LightBlue
        Me.Label76.Location = New System.Drawing.Point(2, 27)
        Me.Label76.Margin = New System.Windows.Forms.Padding(1)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(13, 10)
        Me.Label76.TabIndex = 53
        Me.Label76.Text = "ï"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label75.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.LightBlue
        Me.Label75.Location = New System.Drawing.Point(107, 27)
        Me.Label75.Margin = New System.Windows.Forms.Padding(1)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(13, 10)
        Me.Label75.TabIndex = 52
        Me.Label75.Text = "ð"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbAdjustSelect
        '
        Me.tbAdjustSelect.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustSelect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustSelect.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustSelect.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustSelect.Location = New System.Drawing.Point(61, 32)
        Me.tbAdjustSelect.Multiline = True
        Me.tbAdjustSelect.Name = "tbAdjustSelect"
        Me.tbAdjustSelect.ReadOnly = True
        Me.tbAdjustSelect.Size = New System.Drawing.Size(30, 11)
        Me.tbAdjustSelect.TabIndex = 51
        Me.tbAdjustSelect.Text = "0000"
        Me.tbAdjustSelect.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label42.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.LightBlue
        Me.Label42.Location = New System.Drawing.Point(41, 11)
        Me.Label42.Margin = New System.Windows.Forms.Padding(1)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(41, 10)
        Me.Label42.TabIndex = 50
        Me.Label42.Text = "Select"
        '
        'tbAdjustTotal
        '
        Me.tbAdjustTotal.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustTotal.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustTotal.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustTotal.Location = New System.Drawing.Point(30, 32)
        Me.tbAdjustTotal.Multiline = True
        Me.tbAdjustTotal.Name = "tbAdjustTotal"
        Me.tbAdjustTotal.ReadOnly = True
        Me.tbAdjustTotal.Size = New System.Drawing.Size(30, 11)
        Me.tbAdjustTotal.TabIndex = 49
        Me.tbAdjustTotal.Text = "0000"
        Me.tbAdjustTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnAdjustVright
        '
        Me.btnAdjustVright.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustVright.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustVright.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustVright.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustVright.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnAdjustVright.ForeColor = System.Drawing.Color.LightBlue
        Me.btnAdjustVright.Location = New System.Drawing.Point(94, 33)
        Me.btnAdjustVright.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustVright.Name = "btnAdjustVright"
        Me.btnAdjustVright.Size = New System.Drawing.Size(12, 12)
        Me.btnAdjustVright.TabIndex = 48
        Me.btnAdjustVright.UseVisualStyleBackColor = True
        '
        'btnAdjustVleft
        '
        Me.btnAdjustVleft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustVleft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustVleft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustVleft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustVleft.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnAdjustVleft.ForeColor = System.Drawing.Color.LightBlue
        Me.btnAdjustVleft.Location = New System.Drawing.Point(15, 33)
        Me.btnAdjustVleft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustVleft.Name = "btnAdjustVleft"
        Me.btnAdjustVleft.Size = New System.Drawing.Size(12, 12)
        Me.btnAdjustVleft.TabIndex = 47
        Me.btnAdjustVleft.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label36.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.LightBlue
        Me.Label36.Location = New System.Drawing.Point(104, 45)
        Me.Label36.Margin = New System.Windows.Forms.Padding(1)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(12, 10)
        Me.Label36.TabIndex = 23
        Me.Label36.Text = "ñ"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label37.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.LightBlue
        Me.Label37.Location = New System.Drawing.Point(81, 46)
        Me.Label37.Margin = New System.Windows.Forms.Padding(1)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(12, 10)
        Me.Label37.TabIndex = 22
        Me.Label37.Text = "ò"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label38.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.LightBlue
        Me.Label38.Location = New System.Drawing.Point(26, 46)
        Me.Label38.Margin = New System.Windows.Forms.Padding(1)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(41, 10)
        Me.Label38.TabIndex = 21
        Me.Label38.Text = "Vertex"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label39.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.LightBlue
        Me.Label39.Location = New System.Drawing.Point(4, 82)
        Me.Label39.Margin = New System.Windows.Forms.Padding(1)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(11, 10)
        Me.Label39.TabIndex = 20
        Me.Label39.Text = "Z"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label40.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.LightBlue
        Me.Label40.Location = New System.Drawing.Point(4, 70)
        Me.Label40.Margin = New System.Windows.Forms.Padding(1)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(11, 10)
        Me.Label40.TabIndex = 19
        Me.Label40.Text = "Y"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label41.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.LightBlue
        Me.Label41.Location = New System.Drawing.Point(4, 58)
        Me.Label41.Margin = New System.Windows.Forms.Padding(1)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(11, 10)
        Me.Label41.TabIndex = 18
        Me.Label41.Text = "X"
        '
        'tbAdjustVZ
        '
        Me.tbAdjustVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustVZ.Location = New System.Drawing.Point(19, 82)
        Me.tbAdjustVZ.Multiline = True
        Me.tbAdjustVZ.Name = "tbAdjustVZ"
        Me.tbAdjustVZ.ReadOnly = True
        Me.tbAdjustVZ.Size = New System.Drawing.Size(55, 10)
        Me.tbAdjustVZ.TabIndex = 17
        Me.tbAdjustVZ.Text = "00000.000"
        Me.tbAdjustVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbAdjustVY
        '
        Me.tbAdjustVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustVY.Location = New System.Drawing.Point(19, 70)
        Me.tbAdjustVY.Multiline = True
        Me.tbAdjustVY.Name = "tbAdjustVY"
        Me.tbAdjustVY.ReadOnly = True
        Me.tbAdjustVY.Size = New System.Drawing.Size(55, 10)
        Me.tbAdjustVY.TabIndex = 16
        Me.tbAdjustVY.Text = "00000.000"
        Me.tbAdjustVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbAdjustVX
        '
        Me.tbAdjustVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbAdjustVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbAdjustVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAdjustVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbAdjustVX.Location = New System.Drawing.Point(19, 58)
        Me.tbAdjustVX.Multiline = True
        Me.tbAdjustVX.Name = "tbAdjustVX"
        Me.tbAdjustVX.ReadOnly = True
        Me.tbAdjustVX.Size = New System.Drawing.Size(55, 10)
        Me.tbAdjustVX.TabIndex = 15
        Me.tbAdjustVX.Text = "00000.000"
        Me.tbAdjustVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnAdjustXup
        '
        Me.btnAdjustXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustXup.Location = New System.Drawing.Point(99, 58)
        Me.btnAdjustXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustXup.Name = "btnAdjustXup"
        Me.btnAdjustXup.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustXup.TabIndex = 5
        Me.btnAdjustXup.UseVisualStyleBackColor = True
        '
        'btnAdjustXdown
        '
        Me.btnAdjustXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustXdown.Location = New System.Drawing.Point(77, 58)
        Me.btnAdjustXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustXdown.Name = "btnAdjustXdown"
        Me.btnAdjustXdown.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustXdown.TabIndex = 4
        Me.btnAdjustXdown.UseVisualStyleBackColor = True
        '
        'btnAdjustYdown
        '
        Me.btnAdjustYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustYdown.Location = New System.Drawing.Point(77, 70)
        Me.btnAdjustYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustYdown.Name = "btnAdjustYdown"
        Me.btnAdjustYdown.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustYdown.TabIndex = 3
        Me.btnAdjustYdown.UseVisualStyleBackColor = True
        '
        'btnAdjustYup
        '
        Me.btnAdjustYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustYup.Location = New System.Drawing.Point(99, 70)
        Me.btnAdjustYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustYup.Name = "btnAdjustYup"
        Me.btnAdjustYup.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustYup.TabIndex = 2
        Me.btnAdjustYup.UseVisualStyleBackColor = True
        '
        'btnAdjustZdown
        '
        Me.btnAdjustZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustZdown.Location = New System.Drawing.Point(77, 82)
        Me.btnAdjustZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustZdown.Name = "btnAdjustZdown"
        Me.btnAdjustZdown.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustZdown.TabIndex = 1
        Me.btnAdjustZdown.UseVisualStyleBackColor = True
        '
        'btnAdjustZup
        '
        Me.btnAdjustZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnAdjustZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnAdjustZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdjustZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdjustZup.Location = New System.Drawing.Point(99, 82)
        Me.btnAdjustZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAdjustZup.Name = "btnAdjustZup"
        Me.btnAdjustZup.Size = New System.Drawing.Size(20, 10)
        Me.btnAdjustZup.TabIndex = 0
        Me.btnAdjustZup.UseVisualStyleBackColor = True
        '
        'gbSpin
        '
        Me.gbSpin.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbSpin.Controls.Add(Me.cbApplySpin)
        Me.gbSpin.Controls.Add(Me.Label24)
        Me.gbSpin.Controls.Add(Me.Label26)
        Me.gbSpin.Controls.Add(Me.Label27)
        Me.gbSpin.Controls.Add(Me.Label28)
        Me.gbSpin.Controls.Add(Me.Label29)
        Me.gbSpin.Controls.Add(Me.Label30)
        Me.gbSpin.Controls.Add(Me.tbSpinVZ)
        Me.gbSpin.Controls.Add(Me.tbSpinVY)
        Me.gbSpin.Controls.Add(Me.tbSpinVX)
        Me.gbSpin.Controls.Add(Me.btnSpinXup)
        Me.gbSpin.Controls.Add(Me.btnSpinXdown)
        Me.gbSpin.Controls.Add(Me.btnSpinYdown)
        Me.gbSpin.Controls.Add(Me.btnSpinYup)
        Me.gbSpin.Controls.Add(Me.btnSpinZdown)
        Me.gbSpin.Controls.Add(Me.btnSpinZup)
        Me.gbSpin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbSpin.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbSpin.ForeColor = System.Drawing.SystemColors.Control
        Me.gbSpin.Location = New System.Drawing.Point(132, 329)
        Me.gbSpin.Margin = New System.Windows.Forms.Padding(1)
        Me.gbSpin.Name = "gbSpin"
        Me.gbSpin.Padding = New System.Windows.Forms.Padding(1)
        Me.gbSpin.Size = New System.Drawing.Size(88, 77)
        Me.gbSpin.TabIndex = 37
        Me.gbSpin.TabStop = False
        Me.gbSpin.Text = "Spin"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label24.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.LightBlue
        Me.Label24.Location = New System.Drawing.Point(74, 11)
        Me.Label24.Margin = New System.Windows.Forms.Padding(1)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(12, 10)
        Me.Label24.TabIndex = 23
        Me.Label24.Text = "ñ"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label26.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.LightBlue
        Me.Label26.Location = New System.Drawing.Point(62, 12)
        Me.Label26.Margin = New System.Windows.Forms.Padding(1)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(12, 10)
        Me.Label26.TabIndex = 22
        Me.Label26.Text = "ò"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label27.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.LightBlue
        Me.Label27.Location = New System.Drawing.Point(17, 11)
        Me.Label27.Margin = New System.Windows.Forms.Padding(1)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(41, 10)
        Me.Label27.TabIndex = 21
        Me.Label27.Text = "Radian"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label28.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.LightBlue
        Me.Label28.Location = New System.Drawing.Point(2, 48)
        Me.Label28.Margin = New System.Windows.Forms.Padding(1)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(11, 10)
        Me.Label28.TabIndex = 20
        Me.Label28.Text = "Z"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label29.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.LightBlue
        Me.Label29.Location = New System.Drawing.Point(2, 36)
        Me.Label29.Margin = New System.Windows.Forms.Padding(1)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(11, 10)
        Me.Label29.TabIndex = 19
        Me.Label29.Text = "Y"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label30.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.LightBlue
        Me.Label30.Location = New System.Drawing.Point(2, 24)
        Me.Label30.Margin = New System.Windows.Forms.Padding(1)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(11, 10)
        Me.Label30.TabIndex = 18
        Me.Label30.Text = "X"
        '
        'tbSpinVZ
        '
        Me.tbSpinVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbSpinVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbSpinVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSpinVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbSpinVZ.Location = New System.Drawing.Point(14, 48)
        Me.tbSpinVZ.Multiline = True
        Me.tbSpinVZ.Name = "tbSpinVZ"
        Me.tbSpinVZ.ReadOnly = True
        Me.tbSpinVZ.Size = New System.Drawing.Size(46, 10)
        Me.tbSpinVZ.TabIndex = 17
        Me.tbSpinVZ.Text = "255"
        Me.tbSpinVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbSpinVY
        '
        Me.tbSpinVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbSpinVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbSpinVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSpinVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbSpinVY.Location = New System.Drawing.Point(14, 36)
        Me.tbSpinVY.Multiline = True
        Me.tbSpinVY.Name = "tbSpinVY"
        Me.tbSpinVY.ReadOnly = True
        Me.tbSpinVY.Size = New System.Drawing.Size(46, 10)
        Me.tbSpinVY.TabIndex = 16
        Me.tbSpinVY.Text = "255"
        Me.tbSpinVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbSpinVX
        '
        Me.tbSpinVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbSpinVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbSpinVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSpinVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbSpinVX.Location = New System.Drawing.Point(14, 24)
        Me.tbSpinVX.Multiline = True
        Me.tbSpinVX.Name = "tbSpinVX"
        Me.tbSpinVX.ReadOnly = True
        Me.tbSpinVX.Size = New System.Drawing.Size(46, 10)
        Me.tbSpinVX.TabIndex = 15
        Me.tbSpinVX.Text = "255"
        Me.tbSpinVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnSpinXup
        '
        Me.btnSpinXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinXup.Location = New System.Drawing.Point(74, 24)
        Me.btnSpinXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinXup.Name = "btnSpinXup"
        Me.btnSpinXup.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinXup.TabIndex = 5
        Me.btnSpinXup.UseVisualStyleBackColor = True
        '
        'btnSpinXdown
        '
        Me.btnSpinXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinXdown.Location = New System.Drawing.Point(62, 24)
        Me.btnSpinXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinXdown.Name = "btnSpinXdown"
        Me.btnSpinXdown.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinXdown.TabIndex = 4
        Me.btnSpinXdown.UseVisualStyleBackColor = True
        '
        'btnSpinYdown
        '
        Me.btnSpinYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinYdown.Location = New System.Drawing.Point(62, 36)
        Me.btnSpinYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinYdown.Name = "btnSpinYdown"
        Me.btnSpinYdown.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinYdown.TabIndex = 3
        Me.btnSpinYdown.UseVisualStyleBackColor = True
        '
        'btnSpinYup
        '
        Me.btnSpinYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinYup.Location = New System.Drawing.Point(74, 36)
        Me.btnSpinYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinYup.Name = "btnSpinYup"
        Me.btnSpinYup.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinYup.TabIndex = 2
        Me.btnSpinYup.UseVisualStyleBackColor = True
        '
        'btnSpinZdown
        '
        Me.btnSpinZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinZdown.Location = New System.Drawing.Point(62, 48)
        Me.btnSpinZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinZdown.Name = "btnSpinZdown"
        Me.btnSpinZdown.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinZdown.TabIndex = 1
        Me.btnSpinZdown.UseVisualStyleBackColor = True
        '
        'btnSpinZup
        '
        Me.btnSpinZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSpinZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSpinZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSpinZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpinZup.Location = New System.Drawing.Point(74, 48)
        Me.btnSpinZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSpinZup.Name = "btnSpinZup"
        Me.btnSpinZup.Size = New System.Drawing.Size(10, 10)
        Me.btnSpinZup.TabIndex = 0
        Me.btnSpinZup.UseVisualStyleBackColor = True
        '
        'gbRadius
        '
        Me.gbRadius.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbRadius.Controls.Add(Me.Label20)
        Me.gbRadius.Controls.Add(Me.Label21)
        Me.gbRadius.Controls.Add(Me.Label22)
        Me.gbRadius.Controls.Add(Me.Label25)
        Me.gbRadius.Controls.Add(Me.tbRadiusV)
        Me.gbRadius.Controls.Add(Me.btnRadiusRup)
        Me.gbRadius.Controls.Add(Me.btnRadiusRdown)
        Me.gbRadius.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbRadius.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbRadius.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbRadius.Location = New System.Drawing.Point(6, 346)
        Me.gbRadius.Margin = New System.Windows.Forms.Padding(1)
        Me.gbRadius.Name = "gbRadius"
        Me.gbRadius.Padding = New System.Windows.Forms.Padding(1)
        Me.gbRadius.Size = New System.Drawing.Size(122, 41)
        Me.gbRadius.TabIndex = 36
        Me.gbRadius.TabStop = False
        Me.gbRadius.Text = "Radius"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label20.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.LightBlue
        Me.Label20.Location = New System.Drawing.Point(103, 14)
        Me.Label20.Margin = New System.Windows.Forms.Padding(1)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(12, 10)
        Me.Label20.TabIndex = 23
        Me.Label20.Text = "ñ"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label21.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.LightBlue
        Me.Label21.Location = New System.Drawing.Point(82, 15)
        Me.Label21.Margin = New System.Windows.Forms.Padding(1)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(12, 10)
        Me.Label21.TabIndex = 22
        Me.Label21.Text = "ò"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label22.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.LightBlue
        Me.Label22.Location = New System.Drawing.Point(32, 13)
        Me.Label22.Margin = New System.Windows.Forms.Padding(1)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(29, 10)
        Me.Label22.TabIndex = 21
        Me.Label22.Text = "Size"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label25.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.LightBlue
        Me.Label25.Location = New System.Drawing.Point(4, 27)
        Me.Label25.Margin = New System.Windows.Forms.Padding(1)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(11, 10)
        Me.Label25.TabIndex = 18
        Me.Label25.Text = "R"
        '
        'tbRadiusV
        '
        Me.tbRadiusV.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbRadiusV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbRadiusV.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbRadiusV.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbRadiusV.Location = New System.Drawing.Point(19, 27)
        Me.tbRadiusV.Multiline = True
        Me.tbRadiusV.Name = "tbRadiusV"
        Me.tbRadiusV.ReadOnly = True
        Me.tbRadiusV.Size = New System.Drawing.Size(55, 10)
        Me.tbRadiusV.TabIndex = 15
        Me.tbRadiusV.Text = "0.000"
        Me.tbRadiusV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnRadiusRup
        '
        Me.btnRadiusRup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnRadiusRup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnRadiusRup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRadiusRup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRadiusRup.Location = New System.Drawing.Point(99, 27)
        Me.btnRadiusRup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnRadiusRup.Name = "btnRadiusRup"
        Me.btnRadiusRup.Size = New System.Drawing.Size(20, 10)
        Me.btnRadiusRup.TabIndex = 5
        Me.btnRadiusRup.UseVisualStyleBackColor = True
        '
        'btnRadiusRdown
        '
        Me.btnRadiusRdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnRadiusRdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnRadiusRdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRadiusRdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRadiusRdown.Location = New System.Drawing.Point(77, 27)
        Me.btnRadiusRdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnRadiusRdown.Name = "btnRadiusRdown"
        Me.btnRadiusRdown.Size = New System.Drawing.Size(20, 10)
        Me.btnRadiusRdown.TabIndex = 4
        Me.btnRadiusRdown.UseVisualStyleBackColor = True
        '
        'gbMeasure
        '
        Me.gbMeasure.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbMeasure.Controls.Add(Me.Label14)
        Me.gbMeasure.Controls.Add(Me.Label15)
        Me.gbMeasure.Controls.Add(Me.Label16)
        Me.gbMeasure.Controls.Add(Me.Label17)
        Me.gbMeasure.Controls.Add(Me.Label18)
        Me.gbMeasure.Controls.Add(Me.Label19)
        Me.gbMeasure.Controls.Add(Me.tbMeasureVZ)
        Me.gbMeasure.Controls.Add(Me.tbMeasureVY)
        Me.gbMeasure.Controls.Add(Me.tbMeasureVX)
        Me.gbMeasure.Controls.Add(Me.btnMeasureXup)
        Me.gbMeasure.Controls.Add(Me.btnMeasureXdown)
        Me.gbMeasure.Controls.Add(Me.btnMeasureYdown)
        Me.gbMeasure.Controls.Add(Me.btnMeasureYup)
        Me.gbMeasure.Controls.Add(Me.btnMeasureZdown)
        Me.gbMeasure.Controls.Add(Me.btnMeasureZup)
        Me.gbMeasure.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbMeasure.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbMeasure.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbMeasure.Location = New System.Drawing.Point(6, 211)
        Me.gbMeasure.Margin = New System.Windows.Forms.Padding(1)
        Me.gbMeasure.Name = "gbMeasure"
        Me.gbMeasure.Padding = New System.Windows.Forms.Padding(1)
        Me.gbMeasure.Size = New System.Drawing.Size(122, 65)
        Me.gbMeasure.TabIndex = 35
        Me.gbMeasure.TabStop = False
        Me.gbMeasure.Text = "Measure"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label14.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.LightBlue
        Me.Label14.Location = New System.Drawing.Point(103, 14)
        Me.Label14.Margin = New System.Windows.Forms.Padding(1)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(12, 10)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "ñ"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label15.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.LightBlue
        Me.Label15.Location = New System.Drawing.Point(82, 15)
        Me.Label15.Margin = New System.Windows.Forms.Padding(1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(12, 10)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "ò"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label16.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.LightBlue
        Me.Label16.Location = New System.Drawing.Point(32, 13)
        Me.Label16.Margin = New System.Windows.Forms.Padding(1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(29, 10)
        Me.Label16.TabIndex = 21
        Me.Label16.Text = "Line"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label17.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.LightBlue
        Me.Label17.Location = New System.Drawing.Point(4, 51)
        Me.Label17.Margin = New System.Windows.Forms.Padding(1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(11, 10)
        Me.Label17.TabIndex = 20
        Me.Label17.Text = "Z"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label18.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.LightBlue
        Me.Label18.Location = New System.Drawing.Point(4, 39)
        Me.Label18.Margin = New System.Windows.Forms.Padding(1)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(11, 10)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "Y"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label19.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.LightBlue
        Me.Label19.Location = New System.Drawing.Point(4, 27)
        Me.Label19.Margin = New System.Windows.Forms.Padding(1)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(11, 10)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "X"
        '
        'tbMeasureVZ
        '
        Me.tbMeasureVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMeasureVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMeasureVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMeasureVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMeasureVZ.Location = New System.Drawing.Point(19, 51)
        Me.tbMeasureVZ.Multiline = True
        Me.tbMeasureVZ.Name = "tbMeasureVZ"
        Me.tbMeasureVZ.ReadOnly = True
        Me.tbMeasureVZ.Size = New System.Drawing.Size(55, 10)
        Me.tbMeasureVZ.TabIndex = 17
        Me.tbMeasureVZ.Text = "00000.000"
        Me.tbMeasureVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbMeasureVY
        '
        Me.tbMeasureVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMeasureVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMeasureVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMeasureVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMeasureVY.Location = New System.Drawing.Point(19, 39)
        Me.tbMeasureVY.Multiline = True
        Me.tbMeasureVY.Name = "tbMeasureVY"
        Me.tbMeasureVY.ReadOnly = True
        Me.tbMeasureVY.Size = New System.Drawing.Size(55, 10)
        Me.tbMeasureVY.TabIndex = 16
        Me.tbMeasureVY.Text = "00000.000"
        Me.tbMeasureVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbMeasureVX
        '
        Me.tbMeasureVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbMeasureVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbMeasureVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMeasureVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbMeasureVX.Location = New System.Drawing.Point(19, 27)
        Me.tbMeasureVX.Multiline = True
        Me.tbMeasureVX.Name = "tbMeasureVX"
        Me.tbMeasureVX.ReadOnly = True
        Me.tbMeasureVX.Size = New System.Drawing.Size(55, 10)
        Me.tbMeasureVX.TabIndex = 15
        Me.tbMeasureVX.Text = "00000.000"
        Me.tbMeasureVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnMeasureXup
        '
        Me.btnMeasureXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureXup.Location = New System.Drawing.Point(99, 27)
        Me.btnMeasureXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureXup.Name = "btnMeasureXup"
        Me.btnMeasureXup.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureXup.TabIndex = 5
        Me.btnMeasureXup.UseVisualStyleBackColor = True
        '
        'btnMeasureXdown
        '
        Me.btnMeasureXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureXdown.Location = New System.Drawing.Point(77, 27)
        Me.btnMeasureXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureXdown.Name = "btnMeasureXdown"
        Me.btnMeasureXdown.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureXdown.TabIndex = 4
        Me.btnMeasureXdown.UseVisualStyleBackColor = True
        '
        'btnMeasureYdown
        '
        Me.btnMeasureYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureYdown.Location = New System.Drawing.Point(77, 39)
        Me.btnMeasureYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureYdown.Name = "btnMeasureYdown"
        Me.btnMeasureYdown.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureYdown.TabIndex = 3
        Me.btnMeasureYdown.UseVisualStyleBackColor = True
        '
        'btnMeasureYup
        '
        Me.btnMeasureYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureYup.Location = New System.Drawing.Point(99, 39)
        Me.btnMeasureYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureYup.Name = "btnMeasureYup"
        Me.btnMeasureYup.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureYup.TabIndex = 2
        Me.btnMeasureYup.UseVisualStyleBackColor = True
        '
        'btnMeasureZdown
        '
        Me.btnMeasureZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureZdown.Location = New System.Drawing.Point(77, 51)
        Me.btnMeasureZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureZdown.Name = "btnMeasureZdown"
        Me.btnMeasureZdown.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureZdown.TabIndex = 1
        Me.btnMeasureZdown.UseVisualStyleBackColor = True
        '
        'btnMeasureZup
        '
        Me.btnMeasureZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnMeasureZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnMeasureZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMeasureZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMeasureZup.Location = New System.Drawing.Point(99, 51)
        Me.btnMeasureZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnMeasureZup.Name = "btnMeasureZup"
        Me.btnMeasureZup.Size = New System.Drawing.Size(20, 10)
        Me.btnMeasureZup.TabIndex = 0
        Me.btnMeasureZup.UseVisualStyleBackColor = True
        '
        'gbPaint
        '
        Me.gbPaint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPaint.Controls.Add(Me.btnColorSwitchB)
        Me.gbPaint.Controls.Add(Me.btnColorSwitchG)
        Me.gbPaint.Controls.Add(Me.btnColorSwitchR)
        Me.gbPaint.Controls.Add(Me.btnColorSwitchA)
        Me.gbPaint.Controls.Add(Me.cbDrawmesh)
        Me.gbPaint.Controls.Add(Me.Label13)
        Me.gbPaint.Controls.Add(Me.tbPaintVB)
        Me.gbPaint.Controls.Add(Me.btnPaintBdown)
        Me.gbPaint.Controls.Add(Me.btnPaintBup)
        Me.gbPaint.Controls.Add(Me.Label7)
        Me.gbPaint.Controls.Add(Me.Label8)
        Me.gbPaint.Controls.Add(Me.Label9)
        Me.gbPaint.Controls.Add(Me.Label10)
        Me.gbPaint.Controls.Add(Me.Label11)
        Me.gbPaint.Controls.Add(Me.Label12)
        Me.gbPaint.Controls.Add(Me.tbPaintVG)
        Me.gbPaint.Controls.Add(Me.tbPaintVR)
        Me.gbPaint.Controls.Add(Me.tbPaintVA)
        Me.gbPaint.Controls.Add(Me.btnPaintAup)
        Me.gbPaint.Controls.Add(Me.btnPaintAdown)
        Me.gbPaint.Controls.Add(Me.btnPaintRdown)
        Me.gbPaint.Controls.Add(Me.btnPaintRup)
        Me.gbPaint.Controls.Add(Me.btnPaintGdown)
        Me.gbPaint.Controls.Add(Me.btnPaintGup)
        Me.gbPaint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbPaint.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPaint.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbPaint.Location = New System.Drawing.Point(132, 144)
        Me.gbPaint.Margin = New System.Windows.Forms.Padding(1)
        Me.gbPaint.Name = "gbPaint"
        Me.gbPaint.Padding = New System.Windows.Forms.Padding(1)
        Me.gbPaint.Size = New System.Drawing.Size(88, 91)
        Me.gbPaint.TabIndex = 34
        Me.gbPaint.TabStop = False
        Me.gbPaint.Text = "Paint"
        '
        'btnColorSwitchB
        '
        Me.btnColorSwitchB.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchB.Location = New System.Drawing.Point(40, 61)
        Me.btnColorSwitchB.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchB.Name = "btnColorSwitchB"
        Me.btnColorSwitchB.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchB.TabIndex = 33
        Me.btnColorSwitchB.UseVisualStyleBackColor = True
        '
        'btnColorSwitchG
        '
        Me.btnColorSwitchG.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchG.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchG.Location = New System.Drawing.Point(40, 49)
        Me.btnColorSwitchG.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchG.Name = "btnColorSwitchG"
        Me.btnColorSwitchG.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchG.TabIndex = 32
        Me.btnColorSwitchG.UseVisualStyleBackColor = True
        '
        'btnColorSwitchR
        '
        Me.btnColorSwitchR.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchR.Location = New System.Drawing.Point(40, 37)
        Me.btnColorSwitchR.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchR.Name = "btnColorSwitchR"
        Me.btnColorSwitchR.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchR.TabIndex = 31
        Me.btnColorSwitchR.UseVisualStyleBackColor = True
        '
        'btnColorSwitchA
        '
        Me.btnColorSwitchA.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnColorSwitchA.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnColorSwitchA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColorSwitchA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnColorSwitchA.Location = New System.Drawing.Point(40, 25)
        Me.btnColorSwitchA.Margin = New System.Windows.Forms.Padding(1)
        Me.btnColorSwitchA.Name = "btnColorSwitchA"
        Me.btnColorSwitchA.Size = New System.Drawing.Size(20, 10)
        Me.btnColorSwitchA.TabIndex = 30
        Me.btnColorSwitchA.UseVisualStyleBackColor = True
        '
        'cbDrawmesh
        '
        Me.cbDrawmesh.AutoSize = True
        Me.cbDrawmesh.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbDrawmesh.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbDrawmesh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbDrawmesh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbDrawmesh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbDrawmesh.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbDrawmesh.ForeColor = System.Drawing.Color.LightBlue
        Me.cbDrawmesh.Location = New System.Drawing.Point(6, 74)
        Me.cbDrawmesh.Name = "cbDrawmesh"
        Me.cbDrawmesh.Size = New System.Drawing.Size(66, 13)
        Me.cbDrawmesh.TabIndex = 28
        Me.cbDrawmesh.Text = "Draw Mesh"
        Me.cbDrawmesh.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label13.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.LightBlue
        Me.Label13.Location = New System.Drawing.Point(2, 61)
        Me.Label13.Margin = New System.Windows.Forms.Padding(1)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(11, 10)
        Me.Label13.TabIndex = 27
        Me.Label13.Text = "B"
        '
        'tbPaintVB
        '
        Me.tbPaintVB.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVB.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVB.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVB.Location = New System.Drawing.Point(14, 61)
        Me.tbPaintVB.Multiline = True
        Me.tbPaintVB.Name = "tbPaintVB"
        Me.tbPaintVB.ReadOnly = True
        Me.tbPaintVB.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVB.TabIndex = 26
        Me.tbPaintVB.Text = "255"
        Me.tbPaintVB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPaintBdown
        '
        Me.btnPaintBdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintBdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintBdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintBdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintBdown.Location = New System.Drawing.Point(62, 61)
        Me.btnPaintBdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintBdown.Name = "btnPaintBdown"
        Me.btnPaintBdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintBdown.TabIndex = 25
        Me.btnPaintBdown.UseVisualStyleBackColor = True
        '
        'btnPaintBup
        '
        Me.btnPaintBup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintBup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintBup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintBup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintBup.Location = New System.Drawing.Point(74, 61)
        Me.btnPaintBup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintBup.Name = "btnPaintBup"
        Me.btnPaintBup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintBup.TabIndex = 24
        Me.btnPaintBup.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.LightBlue
        Me.Label7.Location = New System.Drawing.Point(74, 12)
        Me.Label7.Margin = New System.Windows.Forms.Padding(1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(12, 10)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "ñ"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label8.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.LightBlue
        Me.Label8.Location = New System.Drawing.Point(61, 13)
        Me.Label8.Margin = New System.Windows.Forms.Padding(1)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(12, 10)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "ò"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label9.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.LightBlue
        Me.Label9.Location = New System.Drawing.Point(10, 12)
        Me.Label9.Margin = New System.Windows.Forms.Padding(1)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 10)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Mesh"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label10.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.LightBlue
        Me.Label10.Location = New System.Drawing.Point(2, 49)
        Me.Label10.Margin = New System.Windows.Forms.Padding(1)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(11, 10)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "G"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label11.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.LightBlue
        Me.Label11.Location = New System.Drawing.Point(2, 37)
        Me.Label11.Margin = New System.Windows.Forms.Padding(1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(11, 10)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "R"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label12.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.LightBlue
        Me.Label12.Location = New System.Drawing.Point(2, 25)
        Me.Label12.Margin = New System.Windows.Forms.Padding(1)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(11, 10)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "A"
        '
        'tbPaintVG
        '
        Me.tbPaintVG.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVG.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVG.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVG.Location = New System.Drawing.Point(14, 49)
        Me.tbPaintVG.Multiline = True
        Me.tbPaintVG.Name = "tbPaintVG"
        Me.tbPaintVG.ReadOnly = True
        Me.tbPaintVG.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVG.TabIndex = 17
        Me.tbPaintVG.Text = "255"
        Me.tbPaintVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPaintVR
        '
        Me.tbPaintVR.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVR.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVR.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVR.Location = New System.Drawing.Point(14, 37)
        Me.tbPaintVR.Multiline = True
        Me.tbPaintVR.Name = "tbPaintVR"
        Me.tbPaintVR.ReadOnly = True
        Me.tbPaintVR.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVR.TabIndex = 16
        Me.tbPaintVR.Text = "255"
        Me.tbPaintVR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPaintVA
        '
        Me.tbPaintVA.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbPaintVA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbPaintVA.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPaintVA.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbPaintVA.Location = New System.Drawing.Point(14, 25)
        Me.tbPaintVA.Multiline = True
        Me.tbPaintVA.Name = "tbPaintVA"
        Me.tbPaintVA.ReadOnly = True
        Me.tbPaintVA.Size = New System.Drawing.Size(24, 10)
        Me.tbPaintVA.TabIndex = 15
        Me.tbPaintVA.Text = "255"
        Me.tbPaintVA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPaintAup
        '
        Me.btnPaintAup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintAup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintAup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintAup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintAup.Location = New System.Drawing.Point(74, 25)
        Me.btnPaintAup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintAup.Name = "btnPaintAup"
        Me.btnPaintAup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintAup.TabIndex = 5
        Me.btnPaintAup.UseVisualStyleBackColor = True
        '
        'btnPaintAdown
        '
        Me.btnPaintAdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintAdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintAdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintAdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintAdown.Location = New System.Drawing.Point(62, 25)
        Me.btnPaintAdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintAdown.Name = "btnPaintAdown"
        Me.btnPaintAdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintAdown.TabIndex = 4
        Me.btnPaintAdown.UseVisualStyleBackColor = True
        '
        'btnPaintRdown
        '
        Me.btnPaintRdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintRdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintRdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintRdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintRdown.Location = New System.Drawing.Point(62, 37)
        Me.btnPaintRdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintRdown.Name = "btnPaintRdown"
        Me.btnPaintRdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintRdown.TabIndex = 3
        Me.btnPaintRdown.UseVisualStyleBackColor = True
        '
        'btnPaintRup
        '
        Me.btnPaintRup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintRup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintRup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintRup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintRup.Location = New System.Drawing.Point(74, 37)
        Me.btnPaintRup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintRup.Name = "btnPaintRup"
        Me.btnPaintRup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintRup.TabIndex = 2
        Me.btnPaintRup.UseVisualStyleBackColor = True
        '
        'btnPaintGdown
        '
        Me.btnPaintGdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintGdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintGdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintGdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintGdown.Location = New System.Drawing.Point(62, 49)
        Me.btnPaintGdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintGdown.Name = "btnPaintGdown"
        Me.btnPaintGdown.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintGdown.TabIndex = 1
        Me.btnPaintGdown.UseVisualStyleBackColor = True
        '
        'btnPaintGup
        '
        Me.btnPaintGup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPaintGup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPaintGup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPaintGup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPaintGup.Location = New System.Drawing.Point(74, 49)
        Me.btnPaintGup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPaintGup.Name = "btnPaintGup"
        Me.btnPaintGup.Size = New System.Drawing.Size(10, 10)
        Me.btnPaintGup.TabIndex = 0
        Me.btnPaintGup.UseVisualStyleBackColor = True
        '
        'gbOrigin
        '
        Me.gbOrigin.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbOrigin.Controls.Add(Me.Label6)
        Me.gbOrigin.Controls.Add(Me.Label5)
        Me.gbOrigin.Controls.Add(Me.Label4)
        Me.gbOrigin.Controls.Add(Me.Label3)
        Me.gbOrigin.Controls.Add(Me.Label2)
        Me.gbOrigin.Controls.Add(Me.Label1)
        Me.gbOrigin.Controls.Add(Me.tbOriginVZ)
        Me.gbOrigin.Controls.Add(Me.tbOriginVY)
        Me.gbOrigin.Controls.Add(Me.tbOriginVX)
        Me.gbOrigin.Controls.Add(Me.btnOriginXup)
        Me.gbOrigin.Controls.Add(Me.btnOriginXdown)
        Me.gbOrigin.Controls.Add(Me.btnOriginYdown)
        Me.gbOrigin.Controls.Add(Me.btnOriginYup)
        Me.gbOrigin.Controls.Add(Me.btnOriginZdown)
        Me.gbOrigin.Controls.Add(Me.btnOriginZup)
        Me.gbOrigin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbOrigin.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbOrigin.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbOrigin.Location = New System.Drawing.Point(6, 144)
        Me.gbOrigin.Margin = New System.Windows.Forms.Padding(1)
        Me.gbOrigin.Name = "gbOrigin"
        Me.gbOrigin.Padding = New System.Windows.Forms.Padding(1)
        Me.gbOrigin.Size = New System.Drawing.Size(122, 65)
        Me.gbOrigin.TabIndex = 32
        Me.gbOrigin.TabStop = False
        Me.gbOrigin.Text = "Origin"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label6.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.LightBlue
        Me.Label6.Location = New System.Drawing.Point(103, 14)
        Me.Label6.Margin = New System.Windows.Forms.Padding(1)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(12, 10)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "ñ"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label5.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.LightBlue
        Me.Label5.Location = New System.Drawing.Point(82, 15)
        Me.Label5.Margin = New System.Windows.Forms.Padding(1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(12, 10)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "ò"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.LightBlue
        Me.Label4.Location = New System.Drawing.Point(29, 13)
        Me.Label4.Margin = New System.Windows.Forms.Padding(1)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 10)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Point"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label3.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.LightBlue
        Me.Label3.Location = New System.Drawing.Point(4, 51)
        Me.Label3.Margin = New System.Windows.Forms.Padding(1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(11, 10)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Z"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightBlue
        Me.Label2.Location = New System.Drawing.Point(4, 39)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(11, 10)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Y"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.LightBlue
        Me.Label1.Location = New System.Drawing.Point(4, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(11, 10)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "X"
        '
        'tbOriginVZ
        '
        Me.tbOriginVZ.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbOriginVZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbOriginVZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbOriginVZ.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbOriginVZ.Location = New System.Drawing.Point(19, 51)
        Me.tbOriginVZ.Multiline = True
        Me.tbOriginVZ.Name = "tbOriginVZ"
        Me.tbOriginVZ.ReadOnly = True
        Me.tbOriginVZ.Size = New System.Drawing.Size(55, 10)
        Me.tbOriginVZ.TabIndex = 17
        Me.tbOriginVZ.Text = "00000.000"
        Me.tbOriginVZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbOriginVY
        '
        Me.tbOriginVY.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbOriginVY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbOriginVY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbOriginVY.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbOriginVY.Location = New System.Drawing.Point(19, 39)
        Me.tbOriginVY.Multiline = True
        Me.tbOriginVY.Name = "tbOriginVY"
        Me.tbOriginVY.ReadOnly = True
        Me.tbOriginVY.Size = New System.Drawing.Size(55, 10)
        Me.tbOriginVY.TabIndex = 16
        Me.tbOriginVY.Text = "00000.000"
        Me.tbOriginVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbOriginVX
        '
        Me.tbOriginVX.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbOriginVX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbOriginVX.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbOriginVX.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbOriginVX.Location = New System.Drawing.Point(19, 27)
        Me.tbOriginVX.Multiline = True
        Me.tbOriginVX.Name = "tbOriginVX"
        Me.tbOriginVX.ReadOnly = True
        Me.tbOriginVX.Size = New System.Drawing.Size(55, 10)
        Me.tbOriginVX.TabIndex = 15
        Me.tbOriginVX.Text = "00000.000"
        Me.tbOriginVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnOriginXup
        '
        Me.btnOriginXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginXup.Location = New System.Drawing.Point(99, 27)
        Me.btnOriginXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginXup.Name = "btnOriginXup"
        Me.btnOriginXup.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginXup.TabIndex = 5
        Me.btnOriginXup.UseVisualStyleBackColor = True
        '
        'btnOriginXdown
        '
        Me.btnOriginXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginXdown.Location = New System.Drawing.Point(77, 27)
        Me.btnOriginXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginXdown.Name = "btnOriginXdown"
        Me.btnOriginXdown.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginXdown.TabIndex = 4
        Me.btnOriginXdown.UseVisualStyleBackColor = True
        '
        'btnOriginYdown
        '
        Me.btnOriginYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginYdown.Location = New System.Drawing.Point(77, 39)
        Me.btnOriginYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginYdown.Name = "btnOriginYdown"
        Me.btnOriginYdown.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginYdown.TabIndex = 3
        Me.btnOriginYdown.UseVisualStyleBackColor = True
        '
        'btnOriginYup
        '
        Me.btnOriginYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginYup.Location = New System.Drawing.Point(99, 39)
        Me.btnOriginYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginYup.Name = "btnOriginYup"
        Me.btnOriginYup.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginYup.TabIndex = 2
        Me.btnOriginYup.UseVisualStyleBackColor = True
        '
        'btnOriginZdown
        '
        Me.btnOriginZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginZdown.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOriginZdown.Location = New System.Drawing.Point(77, 51)
        Me.btnOriginZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginZdown.Name = "btnOriginZdown"
        Me.btnOriginZdown.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginZdown.TabIndex = 1
        Me.btnOriginZdown.UseVisualStyleBackColor = True
        '
        'btnOriginZup
        '
        Me.btnOriginZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnOriginZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnOriginZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOriginZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOriginZup.Location = New System.Drawing.Point(99, 51)
        Me.btnOriginZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOriginZup.Name = "btnOriginZup"
        Me.btnOriginZup.Size = New System.Drawing.Size(20, 10)
        Me.btnOriginZup.TabIndex = 0
        Me.btnOriginZup.UseVisualStyleBackColor = True
        '
        'tbLog
        '
        Me.tbLog.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbLog.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbLog.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbLog.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbLog.Location = New System.Drawing.Point(283, 8)
        Me.tbLog.Margin = New System.Windows.Forms.Padding(4)
        Me.tbLog.Multiline = True
        Me.tbLog.Name = "tbLog"
        Me.tbLog.Size = New System.Drawing.Size(226, 32)
        Me.tbLog.TabIndex = 14
        Me.tbLog.Text = "Program ready"
        '
        'pViewControl
        '
        Me.pViewControl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pViewControl.BackColor = System.Drawing.Color.Black
        Me.pViewControl.Controls.Add(Me.tbLabel)
        Me.pViewControl.Controls.Add(Me.gbGhost)
        Me.pViewControl.Controls.Add(Me.GroupBox5)
        Me.pViewControl.Controls.Add(Me.GroupBox4)
        Me.pViewControl.Controls.Add(Me.GroupBox3)
        Me.pViewControl.Controls.Add(Me.tbLog)
        Me.pViewControl.Location = New System.Drawing.Point(0, 442)
        Me.pViewControl.Name = "pViewControl"
        Me.pViewControl.Size = New System.Drawing.Size(839, 72)
        Me.pViewControl.TabIndex = 15
        '
        'tbLabel
        '
        Me.tbLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbLabel.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbLabel.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbLabel.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbLabel.Location = New System.Drawing.Point(283, 48)
        Me.tbLabel.Margin = New System.Windows.Forms.Padding(4)
        Me.tbLabel.Multiline = True
        Me.tbLabel.Name = "tbLabel"
        Me.tbLabel.Size = New System.Drawing.Size(226, 17)
        Me.tbLabel.TabIndex = 71
        Me.tbLabel.Text = ">"
        '
        'gbGhost
        '
        Me.gbGhost.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbGhost.Controls.Add(Me.cbLockZ)
        Me.gbGhost.Controls.Add(Me.cbLockY)
        Me.gbGhost.Controls.Add(Me.cbLockX)
        Me.gbGhost.Controls.Add(Me.Label77)
        Me.gbGhost.Controls.Add(Me.Label78)
        Me.gbGhost.Controls.Add(Me.btnGhostXright)
        Me.gbGhost.Controls.Add(Me.btnGhostXleft)
        Me.gbGhost.Controls.Add(Me.btnGhostYleft)
        Me.gbGhost.Controls.Add(Me.btnGhostYright)
        Me.gbGhost.Controls.Add(Me.btnGhostZleft)
        Me.gbGhost.Controls.Add(Me.btnGhostZright)
        Me.gbGhost.Controls.Add(Me.Label23)
        Me.gbGhost.Controls.Add(Me.Label31)
        Me.gbGhost.Controls.Add(Me.Label32)
        Me.gbGhost.Controls.Add(Me.Label33)
        Me.gbGhost.Controls.Add(Me.Label34)
        Me.gbGhost.Controls.Add(Me.Label35)
        Me.gbGhost.Controls.Add(Me.btnGhostXup)
        Me.gbGhost.Controls.Add(Me.btnGhostXdown)
        Me.gbGhost.Controls.Add(Me.btnGhostYdown)
        Me.gbGhost.Controls.Add(Me.btnGhostYup)
        Me.gbGhost.Controls.Add(Me.btnGhostZdown)
        Me.gbGhost.Controls.Add(Me.btnGhostZup)
        Me.gbGhost.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbGhost.Font = New System.Drawing.Font("Lucida Fax", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbGhost.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.gbGhost.Location = New System.Drawing.Point(514, 2)
        Me.gbGhost.Margin = New System.Windows.Forms.Padding(1)
        Me.gbGhost.Name = "gbGhost"
        Me.gbGhost.Padding = New System.Windows.Forms.Padding(1)
        Me.gbGhost.Size = New System.Drawing.Size(88, 65)
        Me.gbGhost.TabIndex = 70
        Me.gbGhost.TabStop = False
        Me.gbGhost.Text = "Ghost"
        '
        'cbLockZ
        '
        Me.cbLockZ.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbLockZ.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbLockZ.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbLockZ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbLockZ.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbLockZ.Font = New System.Drawing.Font("Webdings", 5.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cbLockZ.ForeColor = System.Drawing.Color.LightBlue
        Me.cbLockZ.Location = New System.Drawing.Point(17, 48)
        Me.cbLockZ.Name = "cbLockZ"
        Me.cbLockZ.Size = New System.Drawing.Size(16, 11)
        Me.cbLockZ.TabIndex = 38
        Me.cbLockZ.UseVisualStyleBackColor = True
        '
        'cbLockY
        '
        Me.cbLockY.Checked = True
        Me.cbLockY.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbLockY.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbLockY.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbLockY.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbLockY.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbLockY.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbLockY.Font = New System.Drawing.Font("Webdings", 5.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cbLockY.ForeColor = System.Drawing.Color.LightBlue
        Me.cbLockY.Location = New System.Drawing.Point(17, 36)
        Me.cbLockY.Name = "cbLockY"
        Me.cbLockY.Size = New System.Drawing.Size(16, 11)
        Me.cbLockY.TabIndex = 37
        Me.cbLockY.UseVisualStyleBackColor = True
        '
        'cbLockX
        '
        Me.cbLockX.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbLockX.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbLockX.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbLockX.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbLockX.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbLockX.Font = New System.Drawing.Font("Webdings", 5.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cbLockX.ForeColor = System.Drawing.Color.LightBlue
        Me.cbLockX.Location = New System.Drawing.Point(17, 24)
        Me.cbLockX.Name = "cbLockX"
        Me.cbLockX.Size = New System.Drawing.Size(16, 11)
        Me.cbLockX.TabIndex = 36
        Me.cbLockX.UseVisualStyleBackColor = True
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label77.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label77.ForeColor = System.Drawing.Color.LightBlue
        Me.Label77.Location = New System.Drawing.Point(50, 12)
        Me.Label77.Margin = New System.Windows.Forms.Padding(1)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(13, 10)
        Me.Label77.TabIndex = 35
        Me.Label77.Text = "ð"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label78.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.LightBlue
        Me.Label78.Location = New System.Drawing.Point(36, 12)
        Me.Label78.Margin = New System.Windows.Forms.Padding(1)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(13, 10)
        Me.Label78.TabIndex = 34
        Me.Label78.Text = "ï"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnGhostXright
        '
        Me.btnGhostXright.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostXright.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostXright.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostXright.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostXright.Location = New System.Drawing.Point(50, 24)
        Me.btnGhostXright.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostXright.Name = "btnGhostXright"
        Me.btnGhostXright.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostXright.TabIndex = 33
        Me.btnGhostXright.UseVisualStyleBackColor = True
        '
        'btnGhostXleft
        '
        Me.btnGhostXleft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostXleft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostXleft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostXleft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostXleft.Location = New System.Drawing.Point(38, 24)
        Me.btnGhostXleft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostXleft.Name = "btnGhostXleft"
        Me.btnGhostXleft.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostXleft.TabIndex = 32
        Me.btnGhostXleft.UseVisualStyleBackColor = True
        '
        'btnGhostYleft
        '
        Me.btnGhostYleft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostYleft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostYleft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostYleft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostYleft.Location = New System.Drawing.Point(38, 36)
        Me.btnGhostYleft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostYleft.Name = "btnGhostYleft"
        Me.btnGhostYleft.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostYleft.TabIndex = 31
        Me.btnGhostYleft.UseVisualStyleBackColor = True
        '
        'btnGhostYright
        '
        Me.btnGhostYright.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostYright.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostYright.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostYright.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostYright.Location = New System.Drawing.Point(50, 36)
        Me.btnGhostYright.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostYright.Name = "btnGhostYright"
        Me.btnGhostYright.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostYright.TabIndex = 30
        Me.btnGhostYright.UseVisualStyleBackColor = True
        '
        'btnGhostZleft
        '
        Me.btnGhostZleft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostZleft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostZleft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostZleft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostZleft.Location = New System.Drawing.Point(38, 48)
        Me.btnGhostZleft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostZleft.Name = "btnGhostZleft"
        Me.btnGhostZleft.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostZleft.TabIndex = 29
        Me.btnGhostZleft.UseVisualStyleBackColor = True
        '
        'btnGhostZright
        '
        Me.btnGhostZright.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostZright.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostZright.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostZright.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostZright.Location = New System.Drawing.Point(50, 48)
        Me.btnGhostZright.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostZright.Name = "btnGhostZright"
        Me.btnGhostZright.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostZright.TabIndex = 28
        Me.btnGhostZright.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label23.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.LightBlue
        Me.Label23.Location = New System.Drawing.Point(74, 11)
        Me.Label23.Margin = New System.Windows.Forms.Padding(1)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(12, 10)
        Me.Label23.TabIndex = 23
        Me.Label23.Text = "ñ"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label31.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.LightBlue
        Me.Label31.Location = New System.Drawing.Point(62, 12)
        Me.Label31.Margin = New System.Windows.Forms.Padding(1)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(12, 10)
        Me.Label31.TabIndex = 22
        Me.Label31.Text = "ò"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label32.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.LightBlue
        Me.Label32.Location = New System.Drawing.Point(6, 12)
        Me.Label32.Margin = New System.Windows.Forms.Padding(1)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(29, 10)
        Me.Label32.TabIndex = 21
        Me.Label32.Text = "Lock"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label33.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.LightBlue
        Me.Label33.Location = New System.Drawing.Point(2, 49)
        Me.Label33.Margin = New System.Windows.Forms.Padding(1)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(11, 10)
        Me.Label33.TabIndex = 20
        Me.Label33.Text = "Z"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label34.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.LightBlue
        Me.Label34.Location = New System.Drawing.Point(2, 37)
        Me.Label34.Margin = New System.Windows.Forms.Padding(1)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(11, 10)
        Me.Label34.TabIndex = 19
        Me.Label34.Text = "Y"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label35.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.LightBlue
        Me.Label35.Location = New System.Drawing.Point(2, 25)
        Me.Label35.Margin = New System.Windows.Forms.Padding(1)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(11, 10)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "X"
        '
        'btnGhostXup
        '
        Me.btnGhostXup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostXup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostXup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostXup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostXup.Location = New System.Drawing.Point(74, 24)
        Me.btnGhostXup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostXup.Name = "btnGhostXup"
        Me.btnGhostXup.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostXup.TabIndex = 5
        Me.btnGhostXup.UseVisualStyleBackColor = True
        '
        'btnGhostXdown
        '
        Me.btnGhostXdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostXdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostXdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostXdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostXdown.Location = New System.Drawing.Point(62, 24)
        Me.btnGhostXdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostXdown.Name = "btnGhostXdown"
        Me.btnGhostXdown.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostXdown.TabIndex = 4
        Me.btnGhostXdown.UseVisualStyleBackColor = True
        '
        'btnGhostYdown
        '
        Me.btnGhostYdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostYdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostYdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostYdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostYdown.Location = New System.Drawing.Point(62, 36)
        Me.btnGhostYdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostYdown.Name = "btnGhostYdown"
        Me.btnGhostYdown.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostYdown.TabIndex = 3
        Me.btnGhostYdown.UseVisualStyleBackColor = True
        '
        'btnGhostYup
        '
        Me.btnGhostYup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostYup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostYup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostYup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostYup.Location = New System.Drawing.Point(74, 36)
        Me.btnGhostYup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostYup.Name = "btnGhostYup"
        Me.btnGhostYup.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostYup.TabIndex = 2
        Me.btnGhostYup.UseVisualStyleBackColor = True
        '
        'btnGhostZdown
        '
        Me.btnGhostZdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostZdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostZdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostZdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostZdown.Location = New System.Drawing.Point(62, 48)
        Me.btnGhostZdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostZdown.Name = "btnGhostZdown"
        Me.btnGhostZdown.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostZdown.TabIndex = 1
        Me.btnGhostZdown.UseVisualStyleBackColor = True
        '
        'btnGhostZup
        '
        Me.btnGhostZup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGhostZup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGhostZup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGhostZup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGhostZup.Location = New System.Drawing.Point(74, 48)
        Me.btnGhostZup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGhostZup.Name = "btnGhostZup"
        Me.btnGhostZup.Size = New System.Drawing.Size(10, 10)
        Me.btnGhostZup.TabIndex = 0
        Me.btnGhostZup.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.Label74)
        Me.GroupBox5.Controls.Add(Me.Label73)
        Me.GroupBox5.Controls.Add(Me.btnZoomOut)
        Me.GroupBox5.Controls.Add(Me.btnZoomIn)
        Me.GroupBox5.Controls.Add(Me.btnCamSave)
        Me.GroupBox5.Controls.Add(Me.Label62)
        Me.GroupBox5.Controls.Add(Me.Label68)
        Me.GroupBox5.Controls.Add(Me.Label71)
        Me.GroupBox5.Controls.Add(Me.Label72)
        Me.GroupBox5.Controls.Add(Me.btnCamShiftDown)
        Me.GroupBox5.Controls.Add(Me.btnCamShiftUp)
        Me.GroupBox5.Controls.Add(Me.btnCamShiftRight)
        Me.GroupBox5.Controls.Add(Me.btnCamShiftLeft)
        Me.GroupBox5.Controls.Add(Me.btnCamTarget)
        Me.GroupBox5.Controls.Add(Me.Label66)
        Me.GroupBox5.Controls.Add(Me.Label65)
        Me.GroupBox5.Controls.Add(Me.Label64)
        Me.GroupBox5.Controls.Add(Me.Label63)
        Me.GroupBox5.Controls.Add(Me.btnViewdown)
        Me.GroupBox5.Controls.Add(Me.btnViewup)
        Me.GroupBox5.Controls.Add(Me.btnViewright)
        Me.GroupBox5.Controls.Add(Me.btnViewleft)
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox5.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox5.Location = New System.Drawing.Point(158, 3)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox5.Size = New System.Drawing.Size(120, 64)
        Me.GroupBox5.TabIndex = 69
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Camera"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label74.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.LightBlue
        Me.Label74.Location = New System.Drawing.Point(56, 52)
        Me.Label74.Margin = New System.Windows.Forms.Padding(1)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(11, 10)
        Me.Label74.TabIndex = 101
        Me.Label74.Text = "-"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label73.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.Color.LightBlue
        Me.Label73.Location = New System.Drawing.Point(57, 13)
        Me.Label73.Margin = New System.Windows.Forms.Padding(1)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(11, 10)
        Me.Label73.TabIndex = 100
        Me.Label73.Text = "+"
        '
        'btnZoomOut
        '
        Me.btnZoomOut.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnZoomOut.BackColor = System.Drawing.Color.Black
        Me.btnZoomOut.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnZoomOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnZoomOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnZoomOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnZoomOut.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnZoomOut.ForeColor = System.Drawing.Color.LightBlue
        Me.btnZoomOut.Location = New System.Drawing.Point(55, 39)
        Me.btnZoomOut.Margin = New System.Windows.Forms.Padding(1)
        Me.btnZoomOut.Name = "btnZoomOut"
        Me.btnZoomOut.Size = New System.Drawing.Size(12, 12)
        Me.btnZoomOut.TabIndex = 99
        Me.btnZoomOut.UseVisualStyleBackColor = False
        '
        'btnZoomIn
        '
        Me.btnZoomIn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnZoomIn.BackColor = System.Drawing.Color.Black
        Me.btnZoomIn.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnZoomIn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnZoomIn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnZoomIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnZoomIn.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnZoomIn.ForeColor = System.Drawing.Color.LightBlue
        Me.btnZoomIn.Location = New System.Drawing.Point(55, 24)
        Me.btnZoomIn.Margin = New System.Windows.Forms.Padding(1)
        Me.btnZoomIn.Name = "btnZoomIn"
        Me.btnZoomIn.Size = New System.Drawing.Size(12, 12)
        Me.btnZoomIn.TabIndex = 98
        Me.btnZoomIn.UseVisualStyleBackColor = False
        '
        'btnCamSave
        '
        Me.btnCamSave.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamSave.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamSave.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamSave.Location = New System.Drawing.Point(82, 27)
        Me.btnCamSave.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamSave.Name = "btnCamSave"
        Me.btnCamSave.Size = New System.Drawing.Size(20, 20)
        Me.btnCamSave.TabIndex = 94
        Me.btnCamSave.Text = "<"
        Me.btnCamSave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCamSave.UseVisualStyleBackColor = True
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label62.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.LightBlue
        Me.Label62.Location = New System.Drawing.Point(71, 47)
        Me.Label62.Margin = New System.Windows.Forms.Padding(1)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(12, 10)
        Me.Label62.TabIndex = 93
        Me.Label62.Text = "÷"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label68.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label68.ForeColor = System.Drawing.Color.LightBlue
        Me.Label68.Location = New System.Drawing.Point(102, 47)
        Me.Label68.Margin = New System.Windows.Forms.Padding(1)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(12, 10)
        Me.Label68.TabIndex = 92
        Me.Label68.Text = "ø"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label71.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label71.ForeColor = System.Drawing.Color.LightBlue
        Me.Label71.Location = New System.Drawing.Point(102, 17)
        Me.Label71.Margin = New System.Windows.Forms.Padding(1)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(12, 10)
        Me.Label71.TabIndex = 91
        Me.Label71.Text = "ö"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label72.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label72.ForeColor = System.Drawing.Color.LightBlue
        Me.Label72.Location = New System.Drawing.Point(71, 18)
        Me.Label72.Margin = New System.Windows.Forms.Padding(1)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(12, 10)
        Me.Label72.TabIndex = 90
        Me.Label72.Text = "õ"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnCamShiftDown
        '
        Me.btnCamShiftDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCamShiftDown.BackColor = System.Drawing.Color.Black
        Me.btnCamShiftDown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamShiftDown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamShiftDown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamShiftDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamShiftDown.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamShiftDown.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamShiftDown.Location = New System.Drawing.Point(86, 48)
        Me.btnCamShiftDown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamShiftDown.Name = "btnCamShiftDown"
        Me.btnCamShiftDown.Size = New System.Drawing.Size(12, 12)
        Me.btnCamShiftDown.TabIndex = 89
        Me.btnCamShiftDown.UseVisualStyleBackColor = False
        '
        'btnCamShiftUp
        '
        Me.btnCamShiftUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCamShiftUp.BackColor = System.Drawing.Color.Black
        Me.btnCamShiftUp.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamShiftUp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamShiftUp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamShiftUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamShiftUp.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamShiftUp.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamShiftUp.Location = New System.Drawing.Point(86, 14)
        Me.btnCamShiftUp.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamShiftUp.Name = "btnCamShiftUp"
        Me.btnCamShiftUp.Size = New System.Drawing.Size(12, 12)
        Me.btnCamShiftUp.TabIndex = 88
        Me.btnCamShiftUp.UseVisualStyleBackColor = False
        '
        'btnCamShiftRight
        '
        Me.btnCamShiftRight.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCamShiftRight.BackColor = System.Drawing.Color.Black
        Me.btnCamShiftRight.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamShiftRight.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamShiftRight.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamShiftRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamShiftRight.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamShiftRight.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamShiftRight.Location = New System.Drawing.Point(103, 31)
        Me.btnCamShiftRight.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamShiftRight.Name = "btnCamShiftRight"
        Me.btnCamShiftRight.Size = New System.Drawing.Size(12, 12)
        Me.btnCamShiftRight.TabIndex = 87
        Me.btnCamShiftRight.UseVisualStyleBackColor = False
        '
        'btnCamShiftLeft
        '
        Me.btnCamShiftLeft.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCamShiftLeft.BackColor = System.Drawing.Color.Black
        Me.btnCamShiftLeft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamShiftLeft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamShiftLeft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamShiftLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamShiftLeft.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamShiftLeft.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamShiftLeft.Location = New System.Drawing.Point(69, 31)
        Me.btnCamShiftLeft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamShiftLeft.Name = "btnCamShiftLeft"
        Me.btnCamShiftLeft.Size = New System.Drawing.Size(12, 12)
        Me.btnCamShiftLeft.TabIndex = 86
        Me.btnCamShiftLeft.UseVisualStyleBackColor = False
        '
        'btnCamTarget
        '
        Me.btnCamTarget.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnCamTarget.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnCamTarget.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCamTarget.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCamTarget.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnCamTarget.ForeColor = System.Drawing.Color.LightBlue
        Me.btnCamTarget.Location = New System.Drawing.Point(19, 27)
        Me.btnCamTarget.Margin = New System.Windows.Forms.Padding(1)
        Me.btnCamTarget.Name = "btnCamTarget"
        Me.btnCamTarget.Size = New System.Drawing.Size(20, 20)
        Me.btnCamTarget.TabIndex = 85
        Me.btnCamTarget.Text = "°"
        Me.btnCamTarget.UseVisualStyleBackColor = True
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label66.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label66.ForeColor = System.Drawing.Color.LightBlue
        Me.Label66.Location = New System.Drawing.Point(8, 47)
        Me.Label66.Margin = New System.Windows.Forms.Padding(1)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(12, 10)
        Me.Label66.TabIndex = 84
        Me.Label66.Text = "÷"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label65.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label65.ForeColor = System.Drawing.Color.LightBlue
        Me.Label65.Location = New System.Drawing.Point(39, 47)
        Me.Label65.Margin = New System.Windows.Forms.Padding(1)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(12, 10)
        Me.Label65.TabIndex = 83
        Me.Label65.Text = "ø"
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label64.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label64.ForeColor = System.Drawing.Color.LightBlue
        Me.Label64.Location = New System.Drawing.Point(39, 17)
        Me.Label64.Margin = New System.Windows.Forms.Padding(1)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(12, 10)
        Me.Label64.TabIndex = 82
        Me.Label64.Text = "ö"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label63.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.LightBlue
        Me.Label63.Location = New System.Drawing.Point(8, 17)
        Me.Label63.Margin = New System.Windows.Forms.Padding(1)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(12, 10)
        Me.Label63.TabIndex = 81
        Me.Label63.Text = "õ"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnViewdown
        '
        Me.btnViewdown.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnViewdown.BackColor = System.Drawing.Color.Black
        Me.btnViewdown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnViewdown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnViewdown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViewdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewdown.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnViewdown.ForeColor = System.Drawing.Color.LightBlue
        Me.btnViewdown.Location = New System.Drawing.Point(23, 49)
        Me.btnViewdown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnViewdown.Name = "btnViewdown"
        Me.btnViewdown.Size = New System.Drawing.Size(12, 12)
        Me.btnViewdown.TabIndex = 79
        Me.btnViewdown.UseVisualStyleBackColor = False
        '
        'btnViewup
        '
        Me.btnViewup.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnViewup.BackColor = System.Drawing.Color.Black
        Me.btnViewup.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnViewup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnViewup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViewup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewup.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnViewup.ForeColor = System.Drawing.Color.LightBlue
        Me.btnViewup.Location = New System.Drawing.Point(23, 13)
        Me.btnViewup.Margin = New System.Windows.Forms.Padding(1)
        Me.btnViewup.Name = "btnViewup"
        Me.btnViewup.Size = New System.Drawing.Size(12, 12)
        Me.btnViewup.TabIndex = 78
        Me.btnViewup.UseVisualStyleBackColor = False
        '
        'btnViewright
        '
        Me.btnViewright.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnViewright.BackColor = System.Drawing.Color.Black
        Me.btnViewright.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnViewright.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnViewright.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViewright.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewright.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnViewright.ForeColor = System.Drawing.Color.LightBlue
        Me.btnViewright.Location = New System.Drawing.Point(41, 31)
        Me.btnViewright.Margin = New System.Windows.Forms.Padding(1)
        Me.btnViewright.Name = "btnViewright"
        Me.btnViewright.Size = New System.Drawing.Size(12, 12)
        Me.btnViewright.TabIndex = 77
        Me.btnViewright.UseVisualStyleBackColor = False
        '
        'btnViewleft
        '
        Me.btnViewleft.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnViewleft.BackColor = System.Drawing.Color.Black
        Me.btnViewleft.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnViewleft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnViewleft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViewleft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewleft.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnViewleft.ForeColor = System.Drawing.Color.LightBlue
        Me.btnViewleft.Location = New System.Drawing.Point(5, 31)
        Me.btnViewleft.Margin = New System.Windows.Forms.Padding(1)
        Me.btnViewleft.Name = "btnViewleft"
        Me.btnViewleft.Size = New System.Drawing.Size(12, 12)
        Me.btnViewleft.TabIndex = 76
        Me.btnViewleft.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.cbAxisLines)
        Me.GroupBox4.Controls.Add(Me.tbGridDim)
        Me.GroupBox4.Controls.Add(Me.tbGridSize)
        Me.GroupBox4.Controls.Add(Me.btnGridSizeDown)
        Me.GroupBox4.Controls.Add(Me.btnGridSizeUp)
        Me.GroupBox4.Controls.Add(Me.btnGridDimDown)
        Me.GroupBox4.Controls.Add(Me.btnGridDimUp)
        Me.GroupBox4.Controls.Add(Me.Label69)
        Me.GroupBox4.Controls.Add(Me.Label70)
        Me.GroupBox4.Controls.Add(Me.Label67)
        Me.GroupBox4.Controls.Add(Me.cbGridYZ)
        Me.GroupBox4.Controls.Add(Me.cbGridXY)
        Me.GroupBox4.Controls.Add(Me.cbGridXZ)
        Me.GroupBox4.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox4.Location = New System.Drawing.Point(6, 3)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox4.Size = New System.Drawing.Size(148, 64)
        Me.GroupBox4.TabIndex = 67
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Enviroment"
        '
        'cbAxisLines
        '
        Me.cbAxisLines.AutoSize = True
        Me.cbAxisLines.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbAxisLines.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbAxisLines.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbAxisLines.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbAxisLines.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbAxisLines.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAxisLines.ForeColor = System.Drawing.Color.LightBlue
        Me.cbAxisLines.Location = New System.Drawing.Point(66, 13)
        Me.cbAxisLines.Name = "cbAxisLines"
        Me.cbAxisLines.Size = New System.Drawing.Size(71, 13)
        Me.cbAxisLines.TabIndex = 91
        Me.cbAxisLines.Text = "Axis Lines"
        Me.cbAxisLines.UseVisualStyleBackColor = True
        '
        'tbGridDim
        '
        Me.tbGridDim.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbGridDim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbGridDim.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbGridDim.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbGridDim.Location = New System.Drawing.Point(63, 51)
        Me.tbGridDim.Multiline = True
        Me.tbGridDim.Name = "tbGridDim"
        Me.tbGridDim.ReadOnly = True
        Me.tbGridDim.Size = New System.Drawing.Size(37, 10)
        Me.tbGridDim.TabIndex = 90
        Me.tbGridDim.Text = "255"
        Me.tbGridDim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbGridSize
        '
        Me.tbGridSize.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.tbGridSize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbGridSize.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbGridSize.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.tbGridSize.Location = New System.Drawing.Point(63, 39)
        Me.tbGridSize.Multiline = True
        Me.tbGridSize.Name = "tbGridSize"
        Me.tbGridSize.ReadOnly = True
        Me.tbGridSize.Size = New System.Drawing.Size(37, 10)
        Me.tbGridSize.TabIndex = 89
        Me.tbGridSize.Text = "255"
        Me.tbGridSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnGridSizeDown
        '
        Me.btnGridSizeDown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGridSizeDown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGridSizeDown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGridSizeDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGridSizeDown.Location = New System.Drawing.Point(101, 39)
        Me.btnGridSizeDown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGridSizeDown.Name = "btnGridSizeDown"
        Me.btnGridSizeDown.Size = New System.Drawing.Size(20, 10)
        Me.btnGridSizeDown.TabIndex = 88
        Me.btnGridSizeDown.UseVisualStyleBackColor = True
        '
        'btnGridSizeUp
        '
        Me.btnGridSizeUp.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGridSizeUp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGridSizeUp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGridSizeUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGridSizeUp.Location = New System.Drawing.Point(123, 39)
        Me.btnGridSizeUp.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGridSizeUp.Name = "btnGridSizeUp"
        Me.btnGridSizeUp.Size = New System.Drawing.Size(20, 10)
        Me.btnGridSizeUp.TabIndex = 87
        Me.btnGridSizeUp.UseVisualStyleBackColor = True
        '
        'btnGridDimDown
        '
        Me.btnGridDimDown.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGridDimDown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGridDimDown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGridDimDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGridDimDown.Location = New System.Drawing.Point(101, 51)
        Me.btnGridDimDown.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGridDimDown.Name = "btnGridDimDown"
        Me.btnGridDimDown.Size = New System.Drawing.Size(20, 10)
        Me.btnGridDimDown.TabIndex = 86
        Me.btnGridDimDown.UseVisualStyleBackColor = True
        '
        'btnGridDimUp
        '
        Me.btnGridDimUp.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnGridDimUp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGridDimUp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnGridDimUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGridDimUp.Location = New System.Drawing.Point(123, 51)
        Me.btnGridDimUp.Margin = New System.Windows.Forms.Padding(1)
        Me.btnGridDimUp.Name = "btnGridDimUp"
        Me.btnGridDimUp.Size = New System.Drawing.Size(20, 10)
        Me.btnGridDimUp.TabIndex = 85
        Me.btnGridDimUp.UseVisualStyleBackColor = True
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label69.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label69.ForeColor = System.Drawing.Color.LightBlue
        Me.Label69.Location = New System.Drawing.Point(127, 26)
        Me.Label69.Margin = New System.Windows.Forms.Padding(1)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(12, 10)
        Me.Label69.TabIndex = 84
        Me.Label69.Text = "ñ"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label70.Font = New System.Drawing.Font("Wingdings", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label70.ForeColor = System.Drawing.Color.LightBlue
        Me.Label70.Location = New System.Drawing.Point(106, 27)
        Me.Label70.Margin = New System.Windows.Forms.Padding(1)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(12, 10)
        Me.Label70.TabIndex = 83
        Me.Label70.Text = "ò"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label67.Font = New System.Drawing.Font("Lucida Console", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.ForeColor = System.Drawing.Color.LightBlue
        Me.Label67.Location = New System.Drawing.Point(70, 27)
        Me.Label67.Margin = New System.Windows.Forms.Padding(1)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(23, 10)
        Me.Label67.TabIndex = 81
        Me.Label67.Text = "S/D"
        '
        'cbGridYZ
        '
        Me.cbGridYZ.AutoSize = True
        Me.cbGridYZ.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbGridYZ.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbGridYZ.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbGridYZ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbGridYZ.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbGridYZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbGridYZ.ForeColor = System.Drawing.Color.LightBlue
        Me.cbGridYZ.Location = New System.Drawing.Point(5, 47)
        Me.cbGridYZ.Name = "cbGridYZ"
        Me.cbGridYZ.Size = New System.Drawing.Size(56, 13)
        Me.cbGridYZ.TabIndex = 78
        Me.cbGridYZ.Text = "Grid YZ"
        Me.cbGridYZ.UseVisualStyleBackColor = True
        '
        'cbGridXY
        '
        Me.cbGridXY.AutoSize = True
        Me.cbGridXY.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbGridXY.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbGridXY.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbGridXY.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbGridXY.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbGridXY.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbGridXY.ForeColor = System.Drawing.Color.LightBlue
        Me.cbGridXY.Location = New System.Drawing.Point(5, 30)
        Me.cbGridXY.Name = "cbGridXY"
        Me.cbGridXY.Size = New System.Drawing.Size(56, 13)
        Me.cbGridXY.TabIndex = 77
        Me.cbGridXY.Text = "Grid XY"
        Me.cbGridXY.UseVisualStyleBackColor = True
        '
        'cbGridXZ
        '
        Me.cbGridXZ.AutoSize = True
        Me.cbGridXZ.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbGridXZ.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbGridXZ.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbGridXZ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbGridXZ.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbGridXZ.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbGridXZ.ForeColor = System.Drawing.Color.LightBlue
        Me.cbGridXZ.Location = New System.Drawing.Point(5, 13)
        Me.cbGridXZ.Name = "cbGridXZ"
        Me.cbGridXZ.Size = New System.Drawing.Size(56, 13)
        Me.cbGridXZ.TabIndex = 76
        Me.cbGridXZ.Text = "Grid XZ"
        Me.cbGridXZ.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.btnSave)
        Me.GroupBox3.Controls.Add(Me.btnUndo)
        Me.GroupBox3.Controls.Add(Me.btnStep)
        Me.GroupBox3.Controls.Add(Me.btnPress)
        Me.GroupBox3.Controls.Add(Me.btnLoad)
        Me.GroupBox3.Controls.Add(Me.btnRedo)
        Me.GroupBox3.Controls.Add(Me.btnImport)
        Me.GroupBox3.Controls.Add(Me.btnExport)
        Me.GroupBox3.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox3.Location = New System.Drawing.Point(606, 3)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Size = New System.Drawing.Size(228, 64)
        Me.GroupBox3.TabIndex = 65
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Main"
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.LightBlue
        Me.btnSave.Location = New System.Drawing.Point(8, 15)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(50, 20)
        Me.btnSave.TabIndex = 72
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnUndo
        '
        Me.btnUndo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnUndo.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnUndo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnUndo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUndo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUndo.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUndo.ForeColor = System.Drawing.Color.LightBlue
        Me.btnUndo.Location = New System.Drawing.Point(62, 15)
        Me.btnUndo.Margin = New System.Windows.Forms.Padding(1)
        Me.btnUndo.Name = "btnUndo"
        Me.btnUndo.Size = New System.Drawing.Size(50, 20)
        Me.btnUndo.TabIndex = 71
        Me.btnUndo.Text = "Undo"
        Me.btnUndo.UseVisualStyleBackColor = True
        '
        'btnStep
        '
        Me.btnStep.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnStep.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnStep.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnStep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnStep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStep.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStep.ForeColor = System.Drawing.Color.LightBlue
        Me.btnStep.Location = New System.Drawing.Point(169, 15)
        Me.btnStep.Margin = New System.Windows.Forms.Padding(1)
        Me.btnStep.Name = "btnStep"
        Me.btnStep.Size = New System.Drawing.Size(50, 20)
        Me.btnStep.TabIndex = 70
        Me.btnStep.Text = "Set"
        Me.btnStep.UseVisualStyleBackColor = True
        '
        'btnPress
        '
        Me.btnPress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPress.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnPress.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnPress.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPress.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPress.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPress.ForeColor = System.Drawing.Color.LightBlue
        Me.btnPress.Location = New System.Drawing.Point(169, 39)
        Me.btnPress.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPress.Name = "btnPress"
        Me.btnPress.Size = New System.Drawing.Size(50, 20)
        Me.btnPress.TabIndex = 69
        Me.btnPress.Text = "Press"
        Me.btnPress.UseVisualStyleBackColor = True
        '
        'btnLoad
        '
        Me.btnLoad.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnLoad.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnLoad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnLoad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLoad.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoad.ForeColor = System.Drawing.Color.LightBlue
        Me.btnLoad.Location = New System.Drawing.Point(8, 39)
        Me.btnLoad.Margin = New System.Windows.Forms.Padding(1)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(50, 20)
        Me.btnLoad.TabIndex = 68
        Me.btnLoad.Text = "Load"
        Me.btnLoad.UseVisualStyleBackColor = True
        '
        'btnRedo
        '
        Me.btnRedo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRedo.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnRedo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnRedo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRedo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRedo.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRedo.ForeColor = System.Drawing.Color.LightBlue
        Me.btnRedo.Location = New System.Drawing.Point(62, 39)
        Me.btnRedo.Margin = New System.Windows.Forms.Padding(1)
        Me.btnRedo.Name = "btnRedo"
        Me.btnRedo.Size = New System.Drawing.Size(50, 20)
        Me.btnRedo.TabIndex = 67
        Me.btnRedo.Text = "Reset"
        Me.btnRedo.UseVisualStyleBackColor = True
        '
        'btnImport
        '
        Me.btnImport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnImport.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnImport.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImport.ForeColor = System.Drawing.Color.LightBlue
        Me.btnImport.Location = New System.Drawing.Point(116, 39)
        Me.btnImport.Margin = New System.Windows.Forms.Padding(1)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(50, 20)
        Me.btnImport.TabIndex = 66
        Me.btnImport.Text = "Import"
        Me.btnImport.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnExport.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.btnExport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnExport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExport.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExport.ForeColor = System.Drawing.Color.LightBlue
        Me.btnExport.Location = New System.Drawing.Point(116, 15)
        Me.btnExport.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(50, 20)
        Me.btnExport.TabIndex = 65
        Me.btnExport.Text = "Export"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Black
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainToolStripMenuItem, Me.StyleToolStripMenuItem, Me.GenerateToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1066, 24)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MainToolStripMenuItem
        '
        Me.MainToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ExportToolStripMenuItem, Me.ImportToolStripMenuItem, Me.ClearToolStripMenuItem})
        Me.MainToolStripMenuItem.ForeColor = System.Drawing.Color.LightBlue
        Me.MainToolStripMenuItem.Name = "MainToolStripMenuItem"
        Me.MainToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.MainToolStripMenuItem.Text = "Main"
        '
        'LoadToolStripMenuItem
        '
        Me.LoadToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.LoadToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.LoadToolStripMenuItem.Name = "LoadToolStripMenuItem"
        Me.LoadToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.LoadToolStripMenuItem.Text = "Load"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.SaveToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ExportToolStripMenuItem
        '
        Me.ExportToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ExportToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.ExportToolStripMenuItem.Name = "ExportToolStripMenuItem"
        Me.ExportToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.ExportToolStripMenuItem.Text = "Export"
        '
        'ImportToolStripMenuItem
        '
        Me.ImportToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ImportToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.ImportToolStripMenuItem.Name = "ImportToolStripMenuItem"
        Me.ImportToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.ImportToolStripMenuItem.Text = "Import"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ClearToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.ClearToolStripMenuItem.Text = "Reset"
        '
        'StyleToolStripMenuItem
        '
        Me.StyleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackColorToolStripMenuItem, Me.ForeColorToolStripMenuItem, Me.LabelFontToolStripMenuItem, Me.FrameInfoToolStripMenuItem})
        Me.StyleToolStripMenuItem.ForeColor = System.Drawing.Color.LightBlue
        Me.StyleToolStripMenuItem.Name = "StyleToolStripMenuItem"
        Me.StyleToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.StyleToolStripMenuItem.Text = "Options"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.BackColorToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BackColorToolStripMenuItem.Text = "Back Color"
        '
        'ForeColorToolStripMenuItem
        '
        Me.ForeColorToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ForeColorToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.ForeColorToolStripMenuItem.Name = "ForeColorToolStripMenuItem"
        Me.ForeColorToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ForeColorToolStripMenuItem.Text = "Fore Color"
        '
        'LabelFontToolStripMenuItem
        '
        Me.LabelFontToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.LabelFontToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.LabelFontToolStripMenuItem.Name = "LabelFontToolStripMenuItem"
        Me.LabelFontToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LabelFontToolStripMenuItem.Text = "Label Font"
        '
        'GenerateToolStripMenuItem
        '
        Me.GenerateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XZTileToolStripMenuItem, Me.XYTileToolStripMenuItem, Me.YZTileToolStripMenuItem})
        Me.GenerateToolStripMenuItem.ForeColor = System.Drawing.Color.LightBlue
        Me.GenerateToolStripMenuItem.Name = "GenerateToolStripMenuItem"
        Me.GenerateToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.GenerateToolStripMenuItem.Text = "Generate"
        '
        'XZTileToolStripMenuItem
        '
        Me.XZTileToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.XZTileToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.XZTileToolStripMenuItem.Name = "XZTileToolStripMenuItem"
        Me.XZTileToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.XZTileToolStripMenuItem.Text = "XZ Tile"
        '
        'XYTileToolStripMenuItem
        '
        Me.XYTileToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.XYTileToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.XYTileToolStripMenuItem.Name = "XYTileToolStripMenuItem"
        Me.XYTileToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.XYTileToolStripMenuItem.Text = "XY Tile"
        '
        'YZTileToolStripMenuItem
        '
        Me.YZTileToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.YZTileToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.YZTileToolStripMenuItem.Name = "YZTileToolStripMenuItem"
        Me.YZTileToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.YZTileToolStripMenuItem.Text = "YZ Tile"
        '
        'cbApplySpin
        '
        Me.cbApplySpin.AutoSize = True
        Me.cbApplySpin.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbApplySpin.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbApplySpin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbApplySpin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbApplySpin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbApplySpin.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbApplySpin.ForeColor = System.Drawing.Color.LightBlue
        Me.cbApplySpin.Location = New System.Drawing.Point(6, 60)
        Me.cbApplySpin.Name = "cbApplySpin"
        Me.cbApplySpin.Size = New System.Drawing.Size(71, 13)
        Me.cbApplySpin.TabIndex = 35
        Me.cbApplySpin.Text = "Apply Spin"
        Me.cbApplySpin.UseVisualStyleBackColor = True
        '
        'cbApplyOrbit
        '
        Me.cbApplyOrbit.AutoSize = True
        Me.cbApplyOrbit.FlatAppearance.BorderColor = System.Drawing.Color.Blue
        Me.cbApplyOrbit.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbApplyOrbit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.cbApplyOrbit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cbApplyOrbit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbApplyOrbit.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbApplyOrbit.ForeColor = System.Drawing.Color.LightBlue
        Me.cbApplyOrbit.Location = New System.Drawing.Point(6, 60)
        Me.cbApplyOrbit.Name = "cbApplyOrbit"
        Me.cbApplyOrbit.Size = New System.Drawing.Size(76, 13)
        Me.cbApplyOrbit.TabIndex = 36
        Me.cbApplyOrbit.Text = "Apply Orbit"
        Me.cbApplyOrbit.UseVisualStyleBackColor = True
        '
        'FrameInfoToolStripMenuItem
        '
        Me.FrameInfoToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.FrameInfoToolStripMenuItem.Checked = True
        Me.FrameInfoToolStripMenuItem.CheckOnClick = True
        Me.FrameInfoToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FrameInfoToolStripMenuItem.ForeColor = System.Drawing.Color.SlateGray
        Me.FrameInfoToolStripMenuItem.Name = "FrameInfoToolStripMenuItem"
        Me.FrameInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FrameInfoToolStripMenuItem.Text = "Frame Info"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(1066, 514)
        Me.Controls.Add(Me.pViewControl)
        Me.Controls.Add(Me.pControl)
        Me.Controls.Add(Me.MainDisplay)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Architect"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.MainDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pControl.ResumeLayout(False)
        Me.gbPaintFill.ResumeLayout(False)
        Me.gbPaintFill.PerformLayout()
        Me.gbModV.ResumeLayout(False)
        Me.gbModV.PerformLayout()
        CType(Me.ModelDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbTool.ResumeLayout(False)
        Me.gbTool.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbTranslate.ResumeLayout(False)
        Me.gbTranslate.PerformLayout()
        Me.gbAdjust.ResumeLayout(False)
        Me.gbAdjust.PerformLayout()
        Me.gbSpin.ResumeLayout(False)
        Me.gbSpin.PerformLayout()
        Me.gbRadius.ResumeLayout(False)
        Me.gbRadius.PerformLayout()
        Me.gbMeasure.ResumeLayout(False)
        Me.gbMeasure.PerformLayout()
        Me.gbPaint.ResumeLayout(False)
        Me.gbPaint.PerformLayout()
        Me.gbOrigin.ResumeLayout(False)
        Me.gbOrigin.PerformLayout()
        Me.pViewControl.ResumeLayout(False)
        Me.pViewControl.PerformLayout()
        Me.gbGhost.ResumeLayout(False)
        Me.gbGhost.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents gPress As System.Windows.Forms.Timer
    Friend WithEvents pControl As System.Windows.Forms.Panel
    Friend WithEvents tbLog As System.Windows.Forms.TextBox
    Friend WithEvents gbTool As System.Windows.Forms.GroupBox
    Friend WithEvents cbLabel As System.Windows.Forms.CheckBox
    Friend WithEvents cbTriangle As System.Windows.Forms.CheckBox
    Friend WithEvents cbLine As System.Windows.Forms.CheckBox
    Friend WithEvents cbPrism As System.Windows.Forms.CheckBox
    Friend WithEvents cbComp As System.Windows.Forms.CheckBox
    Friend WithEvents cbSquare As System.Windows.Forms.CheckBox
    Friend WithEvents gbSpin As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents tbSpinVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbSpinVY As System.Windows.Forms.TextBox
    Friend WithEvents tbSpinVX As System.Windows.Forms.TextBox
    Friend WithEvents btnSpinXup As System.Windows.Forms.Button
    Friend WithEvents btnSpinXdown As System.Windows.Forms.Button
    Friend WithEvents btnSpinYdown As System.Windows.Forms.Button
    Friend WithEvents btnSpinYup As System.Windows.Forms.Button
    Friend WithEvents btnSpinZdown As System.Windows.Forms.Button
    Friend WithEvents btnSpinZup As System.Windows.Forms.Button
    Friend WithEvents gbRadius As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents tbRadiusV As System.Windows.Forms.TextBox
    Friend WithEvents btnRadiusRup As System.Windows.Forms.Button
    Friend WithEvents btnRadiusRdown As System.Windows.Forms.Button
    Friend WithEvents gbMeasure As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbMeasureVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbMeasureVY As System.Windows.Forms.TextBox
    Friend WithEvents tbMeasureVX As System.Windows.Forms.TextBox
    Friend WithEvents btnMeasureXup As System.Windows.Forms.Button
    Friend WithEvents btnMeasureXdown As System.Windows.Forms.Button
    Friend WithEvents btnMeasureYdown As System.Windows.Forms.Button
    Friend WithEvents btnMeasureYup As System.Windows.Forms.Button
    Friend WithEvents btnMeasureZdown As System.Windows.Forms.Button
    Friend WithEvents btnMeasureZup As System.Windows.Forms.Button
    Friend WithEvents gbPaint As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tbPaintVB As System.Windows.Forms.TextBox
    Friend WithEvents btnPaintBdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintBup As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbPaintVG As System.Windows.Forms.TextBox
    Friend WithEvents tbPaintVR As System.Windows.Forms.TextBox
    Friend WithEvents tbPaintVA As System.Windows.Forms.TextBox
    Friend WithEvents btnPaintAup As System.Windows.Forms.Button
    Friend WithEvents btnPaintAdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintRdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintRup As System.Windows.Forms.Button
    Friend WithEvents btnPaintGdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintGup As System.Windows.Forms.Button
    Friend WithEvents gbOrigin As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbOriginVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbOriginVY As System.Windows.Forms.TextBox
    Friend WithEvents tbOriginVX As System.Windows.Forms.TextBox
    Friend WithEvents btnOriginXup As System.Windows.Forms.Button
    Friend WithEvents btnOriginXdown As System.Windows.Forms.Button
    Friend WithEvents btnOriginYdown As System.Windows.Forms.Button
    Friend WithEvents btnOriginYup As System.Windows.Forms.Button
    Friend WithEvents btnOriginZdown As System.Windows.Forms.Button
    Friend WithEvents btnOriginZup As System.Windows.Forms.Button
    Friend WithEvents gbTranslate As System.Windows.Forms.GroupBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents tbTranslateVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbTranslateVY As System.Windows.Forms.TextBox
    Friend WithEvents tbTranslateVX As System.Windows.Forms.TextBox
    Friend WithEvents btnTranslateXup As System.Windows.Forms.Button
    Friend WithEvents btnTranslateXdown As System.Windows.Forms.Button
    Friend WithEvents btnTranslateYdown As System.Windows.Forms.Button
    Friend WithEvents btnTranslateYup As System.Windows.Forms.Button
    Friend WithEvents btnTranslateZdown As System.Windows.Forms.Button
    Friend WithEvents btnTranslateZup As System.Windows.Forms.Button
    Friend WithEvents gbAdjust As System.Windows.Forms.GroupBox
    Friend WithEvents tbAdjustSelect As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents tbAdjustTotal As System.Windows.Forms.TextBox
    Friend WithEvents btnAdjustVright As System.Windows.Forms.Button
    Friend WithEvents btnAdjustVleft As System.Windows.Forms.Button
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents tbAdjustVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbAdjustVY As System.Windows.Forms.TextBox
    Friend WithEvents tbAdjustVX As System.Windows.Forms.TextBox
    Friend WithEvents btnAdjustXup As System.Windows.Forms.Button
    Friend WithEvents btnAdjustXdown As System.Windows.Forms.Button
    Friend WithEvents btnAdjustYdown As System.Windows.Forms.Button
    Friend WithEvents btnAdjustYup As System.Windows.Forms.Button
    Friend WithEvents btnAdjustZdown As System.Windows.Forms.Button
    Friend WithEvents btnAdjustZup As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents tbMacroV As System.Windows.Forms.TextBox
    Friend WithEvents tbMicroV As System.Windows.Forms.TextBox
    Friend WithEvents btnMicroup As System.Windows.Forms.Button
    Friend WithEvents btnMicrodown As System.Windows.Forms.Button
    Friend WithEvents btnMacrodown As System.Windows.Forms.Button
    Friend WithEvents btnMacroup As System.Windows.Forms.Button
    Friend WithEvents cbMacro As System.Windows.Forms.CheckBox
    Friend WithEvents cbMicro As System.Windows.Forms.CheckBox
    Friend WithEvents pViewControl As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents tbPeakVZ As System.Windows.Forms.TextBox
    Friend WithEvents tbPeakVY As System.Windows.Forms.TextBox
    Friend WithEvents tbPeakVX As System.Windows.Forms.TextBox
    Friend WithEvents btnPeakXup As System.Windows.Forms.Button
    Friend WithEvents btnPeakXdown As System.Windows.Forms.Button
    Friend WithEvents btnPeakYdown As System.Windows.Forms.Button
    Friend WithEvents btnPeakYup As System.Windows.Forms.Button
    Friend WithEvents btnPeakZdown As System.Windows.Forms.Button
    Friend WithEvents btnPeakZup As System.Windows.Forms.Button
    Friend WithEvents cbDrawmesh As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnUndo As System.Windows.Forms.Button
    Friend WithEvents btnStep As System.Windows.Forms.Button
    Friend WithEvents btnPress As System.Windows.Forms.Button
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents btnRedo As System.Windows.Forms.Button
    Friend WithEvents btnImport As System.Windows.Forms.Button
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents cbAxisLines As System.Windows.Forms.CheckBox
    Friend WithEvents tbGridDim As System.Windows.Forms.TextBox
    Friend WithEvents tbGridSize As System.Windows.Forms.TextBox
    Friend WithEvents btnGridSizeDown As System.Windows.Forms.Button
    Friend WithEvents btnGridSizeUp As System.Windows.Forms.Button
    Friend WithEvents btnGridDimDown As System.Windows.Forms.Button
    Friend WithEvents btnGridDimUp As System.Windows.Forms.Button
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents cbGridYZ As System.Windows.Forms.CheckBox
    Friend WithEvents cbGridXY As System.Windows.Forms.CheckBox
    Friend WithEvents cbGridXZ As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents btnViewdown As System.Windows.Forms.Button
    Friend WithEvents btnViewup As System.Windows.Forms.Button
    Friend WithEvents btnViewright As System.Windows.Forms.Button
    Friend WithEvents btnViewleft As System.Windows.Forms.Button
    Friend WithEvents btnCamSave As System.Windows.Forms.Button
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents btnCamShiftDown As System.Windows.Forms.Button
    Friend WithEvents btnCamShiftUp As System.Windows.Forms.Button
    Friend WithEvents btnCamShiftRight As System.Windows.Forms.Button
    Friend WithEvents btnCamShiftLeft As System.Windows.Forms.Button
    Friend WithEvents btnCamTarget As System.Windows.Forms.Button
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents btnZoomOut As System.Windows.Forms.Button
    Friend WithEvents btnZoomIn As System.Windows.Forms.Button
    Friend WithEvents btnAdjustARight As System.Windows.Forms.Button
    Friend WithEvents btnAdjustALeft As System.Windows.Forms.Button
    Friend WithEvents tbAdjustMacro As System.Windows.Forms.TextBox
    Friend WithEvents tbAdjustMicro As System.Windows.Forms.TextBox
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents btnColorSwitchB As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchG As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchR As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchA As System.Windows.Forms.Button
    Friend WithEvents gbModV As System.Windows.Forms.GroupBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents tbMString As System.Windows.Forms.TextBox
    Friend WithEvents btnModelRight As System.Windows.Forms.Button
    Friend WithEvents btnModelLeft As System.Windows.Forms.Button
    Friend WithEvents ModelDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StyleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gbGhost As System.Windows.Forms.GroupBox
    Friend WithEvents cbLockZ As System.Windows.Forms.CheckBox
    Friend WithEvents cbLockY As System.Windows.Forms.CheckBox
    Friend WithEvents cbLockX As System.Windows.Forms.CheckBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents btnGhostXright As System.Windows.Forms.Button
    Friend WithEvents btnGhostXleft As System.Windows.Forms.Button
    Friend WithEvents btnGhostYleft As System.Windows.Forms.Button
    Friend WithEvents btnGhostYright As System.Windows.Forms.Button
    Friend WithEvents btnGhostZleft As System.Windows.Forms.Button
    Friend WithEvents btnGhostZright As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents btnGhostXup As System.Windows.Forms.Button
    Friend WithEvents btnGhostXdown As System.Windows.Forms.Button
    Friend WithEvents btnGhostYdown As System.Windows.Forms.Button
    Friend WithEvents btnGhostYup As System.Windows.Forms.Button
    Friend WithEvents btnGhostZdown As System.Windows.Forms.Button
    Friend WithEvents btnGhostZup As System.Windows.Forms.Button
    Friend WithEvents gbPaintFill As System.Windows.Forms.GroupBox
    Friend WithEvents cbFillplane As System.Windows.Forms.CheckBox
    Friend WithEvents btnColorSwitchFB As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchFG As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchFR As System.Windows.Forms.Button
    Friend WithEvents btnColorSwitchFA As System.Windows.Forms.Button
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents tbPaintVFB As System.Windows.Forms.TextBox
    Friend WithEvents btnPaintFBdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintFBup As System.Windows.Forms.Button
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents tbPaintVFG As System.Windows.Forms.TextBox
    Friend WithEvents tbPaintVFR As System.Windows.Forms.TextBox
    Friend WithEvents tbPaintVFA As System.Windows.Forms.TextBox
    Friend WithEvents btnPaintFAup As System.Windows.Forms.Button
    Friend WithEvents btnPaintFAdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintFRdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintFRup As System.Windows.Forms.Button
    Friend WithEvents btnPaintFGdown As System.Windows.Forms.Button
    Friend WithEvents btnPaintFGup As System.Windows.Forms.Button
    Friend WithEvents GenerateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XZTileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForeColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XYTileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YZTileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tbLabel As System.Windows.Forms.TextBox
    Friend WithEvents LabelFontToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbApplyOrbit As System.Windows.Forms.CheckBox
    Friend WithEvents cbApplySpin As System.Windows.Forms.CheckBox
    Friend WithEvents FrameInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
